package com.blockbot.auto.solver

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class SolverTest {

    @Test
    fun placeSimpleSquare() {
        val n = 8
        val out = IntArray(n)
        val lines = Board.place(IntArray(n), n, Shape.parse("##", "##"), 0, 0, out)
        assertEquals(0, lines)
        assertEquals(3, out[0])
        assertEquals(3, out[1])
        assertEquals(0, out[2])
    }

    @Test
    fun rejectsOutOfBoundsAndOverlap() {
        val n = 8
        val out = IntArray(n)
        val bar = Shape.parse("###")
        assertEquals(-1, Board.place(IntArray(n), n, bar, 0, 6, out)) // выходит вправо
        assertEquals(-1, Board.place(IntArray(n), n, bar, 8, 0, out)) // выходит вниз
        val rows = IntArray(n)
        rows[0] = 1
        assertEquals(-1, Board.place(rows, n, bar, 0, 0, out)) // пересечение
        assertTrue(Board.place(rows, n, bar, 0, 1, out) >= 0)
    }

    @Test
    fun clearsRowAndColumnSimultaneously() {
        // Полные строка 0 и столбец 0 пересекаются в клетке (0,0).
        // При последовательной очистке столбец 0 «сломался» бы после очистки строки.
        val n = 8
        val full = Board.fullMask(n)
        val rows = IntArray(n)
        rows[0] = full and (1 shl 5).inv() // в строке 0 не хватает клетки (0,5)
        for (i in 1 until n) rows[i] = 1    // столбец 0 заполнен
        val out = IntArray(n)
        val lines = Board.place(rows, n, Shape.parse("#"), 0, 5, out)
        assertEquals(2, lines)
        assertArrayEquals(IntArray(n), out)
    }

    @Test
    fun permutationsCount() {
        assertEquals(1, Solver.permutations(1).size)
        assertEquals(2, Solver.permutations(2).size)
        assertEquals(6, Solver.permutations(3).size)
        assertEquals(6, Solver.permutations(3).map { it.joinToString("") }.toSet().size)
    }

    @Test
    fun orderMatters() {
        // Поле 6×6: заполнено всё, кроме трёх клеток (0,0)-(0,2). Фигура 3×3 помещается
        // только после того, как планка 1×3 закроет дыру и всё очистится.
        val n = 6
        val rows = IntArray(n) { Board.fullMask(n) }
        rows[0] = 0b111000
        val big = Shape.parse("###", "###", "###")
        val bar = Shape.parse("###")
        val plan = Solver(n).solve(rows, listOf(big, bar))
        assertNotNull(plan)
        assertEquals(2, plan!!.moves.size)
        assertEquals(1, plan.moves[0].piece) // сначала планка
        assertEquals(0, plan.moves[1].piece) // затем квадрат 3×3
        assertTrue(plan.moves[0].lines > 0)
    }

    @Test
    fun impossibleMoveMeansGameOver() {
        val n = 8
        val rows = IntArray(n) { Board.fullMask(n) }
        rows[0] = Board.fullMask(n) and 1.inv() // свободна одна клетка (0,0)
        assertNull(Solver(n).solve(rows, listOf(Shape.parse("##", "##"))))
    }

    @Test
    fun placesMaximumPieces() {
        // «Шахматное» поле: свободные клетки не соседствуют, линий нет. Планка 1×2 не помещается
        // никогда, 1×1 помещается без очисток. План обязан поставить ровно одну фигуру: 1×1 (индекс 1).
        val n = 8
        val rows = IntArray(n) { r ->
            var m = 0
            for (c in 0 until n) if ((r + c) % 2 == 1) m = m or (1 shl c)
            m
        }
        val plan = Solver(n).solve(rows, listOf(Shape.parse("##"), Shape.parse("#")))
        assertNotNull(plan)
        assertEquals(1, plan!!.moves.size)
        assertEquals(1, plan.moves[0].piece)
        assertEquals(0, plan.moves[0].lines)
    }

    @Test
    fun safeMoveAvoidsLineClears() {
        val n = 8
        val move = Solver(n).safeMove(IntArray(n), listOf(Shape.parse("##", "##"), Shape.parse("###")))
        assertNotNull(move)
        assertEquals(0, move!!.lines)
    }

    @Test
    fun randomPlansAreLegalAndConsistent() {
        val rnd = Random(42)
        val shapes = listOf(
            Shape.parse("#"), Shape.parse("##"), Shape.parse("###"), Shape.parse("##", "##"),
            Shape.parse("#.", "##"), Shape.parse("###", "#.."), Shape.parse("#####"),
            Shape.parse("###", "###", "###"), Shape.parse("#", "#", "#"),
        )
        repeat(25) {
            val n = 6 + rnd.nextInt(5)
            val rows = IntArray(n) {
                var m = 0
                for (j in 0 until n) if (rnd.nextInt(100) < 35) m = m or (1 shl j)
                m
            }
            Board.clearLines(rows, n)
            val pieces = List(3) { shapes[rnd.nextInt(shapes.size)] }
            val plan = Solver(n).solve(rows, pieces, 1500L) ?: return@repeat
            var cur = rows.copyOf()
            for (mv in plan.moves) {
                val out = IntArray(n)
                val l = Board.place(cur, n, pieces[mv.piece], mv.row, mv.col, out)
                assertTrue(l >= 0)
                assertEquals(mv.lines, l)
                cur = out
            }
            assertArrayEquals(cur, plan.finalRows)
            assertEquals(plan.moves.size, plan.moves.map { it.piece }.toSet().size)
        }
    }
}
