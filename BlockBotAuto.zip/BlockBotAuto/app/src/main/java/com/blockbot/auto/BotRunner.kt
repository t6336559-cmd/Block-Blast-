package com.blockbot.auto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.os.SystemClock
import androidx.annotation.RequiresApi
import com.blockbot.auto.solver.Board
import com.blockbot.auto.solver.Move
import com.blockbot.auto.solver.Shape
import com.blockbot.auto.solver.Solver
import com.blockbot.auto.vision.Calibration
import com.blockbot.auto.vision.Geometry
import com.blockbot.auto.vision.Img
import com.blockbot.auto.vision.PieceRead
import com.blockbot.auto.vision.Reading
import com.blockbot.auto.vision.Vision
import com.blockbot.auto.vision.dist
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.math.sign

/**
 * Главный цикл бота.
 * Раунд: снимок → распознавание поля и 3 фигур → решатель выбирает 3 хода → 3 drag подряд без снимков →
 * ожидание нового набора. Снимок нового раунда заодно проверяет предыдущий (предсказание решателя).
 */
class BotRunner(
    private val ctx: Context,
    private val svc: BotAccessibilityService,
    private val capturer: Capturer,
    private val overlay: Overlay,
    private val gamePkg: String,
) {
    private val prefs = Prefs(ctx)
    private lateinit var cal: Calibration
    private lateinit var solver: Solver
    private var screenW = 0
    private var screenH = 0
    private var lastShotAt = 0L
    private var offX = 0f // смещение пальца относительно центра фигуры, в клетках поля
    private var offY = 1.5f
    private var offsetKnown = false
    private var lastAdjX = 0f
    private var lastAdjY = 0f
    private var moveNo = 0
    private var ratio = 0f
    private var avoidRows: IntArray? = null // клетки, куда фигура не встала ни при каких пробах: на время раунда считаем занятыми
    private var lastImg: Img? = null // последний прочитанный снимок (для сравнения «до/после»)

    private class Replan : Exception()

    /** Фигура встала не туда или не встала совсем: нужен свежий снимок и новый расчёт. */
    private class Reaim : Exception()

    private enum class MoveResult { LANDED, ELSEWHERE, FAILED }

    private class RoundRecord(
        val n: Int,
        val startRows: IntArray,
        val moves: List<Move>,
        val shapes: List<Shape>,
        val predicted: IntArray,
    )

    private sealed class Landing {
        object NoChange : Landing()
        object Unknown : Landing()
        class At(val row: Int, val col: Int) : Landing()
    }

    private sealed class Verdict {
        object Match : Verdict()
        object Mismatch : Verdict()
        class Shift(val dr: Int, val dc: Int) : Verdict()
    }

    /** Возвращает сообщение для пользователя (ошибка, конец игры или лимит). */
    suspend fun run(): String {
        return try {
            runInner()
            "Остановлено"
        } catch (e: CancellationException) {
            throw e
        } catch (e: BotFinish) {
            e.message ?: "Готово"
        } catch (e: BotError) {
            BotLog.add("Ошибка: ${e.message}")
            e.message ?: "Ошибка"
        } catch (t: Throwable) {
            BotLog.add("Сбой: $t")
            "Непредвиденная ошибка: ${t.message ?: t.javaClass.simpleName}"
        }
    }

    private fun status(s: String) {
        BotState.status.value = s
    }

    private fun d(ms: Long): Long = (ms / prefs.speed).toLong().coerceAtLeast(50L)

    private fun dragDuration(): Long = (prefs.dragMs / prefs.speed).toLong().coerceIn(120L, 1500L)

    // ═════════════════════════ Основной цикл ═════════════════════════

    private suspend fun runInner() {
        status("Жду запуска игры…")
        val up = withTimeoutOrNull(12_000L) {
            BotAccessibilityService.foregroundPackage.first { it == gamePkg }
        }
        if (up == null) throw BotError("Игра не вышла на передний план. Откройте игру и нажмите «Старт» ещё раз.")
        status("Автоигра начнётся через 2 с…")
        delay(2000L)

        ratio = prefs.pieceRatio
        loadOffset()
        var rd = calibrate()
        var round: RoundRecord? = null
        var unexplained = 0
        var replans = 0
        var reaims = 0

        while (true) {
            checkpoint()
            val limit = prefs.moveLimit
            if (limit > 0 && moveNo >= limit) throw BotFinish("Достигнут лимит ходов ($limit).")

            // 1) реальное состояние поля; проверка предыдущего раунда по предсказанию
            val rec = round
            val predicted = if (rec != null && rec.n == solver.n) rec.predicted else null
            val field = resolve(rd, predicted)
            if (rec != null && predicted != null) {
                when (val v = verify(rec, field)) {
                    Verdict.Match -> unexplained = 0
                    is Verdict.Shift -> {
                        unexplained = 0
                        BotLog.add("Все ходы раунда сдвинуты на (${v.dr}, ${v.dc}) клеток: корректирую смещение пальца")
                        adjustOffset(v.dr, v.dc)
                    }
                    Verdict.Mismatch -> {
                        unexplained++
                        BotLog.add("Поле не совпало с предсказанием ($unexplained/3): считаю заново по реальному полю")
                        if (unexplained >= 3) {
                            throw BotError(
                                "Ходы 3 раза подряд не совпали с ожиданием. Возможно, неверное смещение пальца: " +
                                    "задайте его вручную в «Настройках».",
                            )
                        }
                    }
                }
            }
            round = null

            // 2) автоподбор смещения пальца (первый запуск)
            if (!offsetKnown) {
                rd = calibrateOffset(rd, field)
                continue
            }

            // 3) решатель
            val hand = rd.pieces
            val shapes = hand.map { it.shape }
            status("Ход ${moveNo + 1} · думаю…")
            val avoid = avoidRows
            val solveField = if (avoid == null) field else IntArray(field.size) { field[it] or avoid[it] }
            var found = solver.solve(solveField, shapes)
            if (found == null && avoid != null) {
                avoidRows = null
                found = solver.solve(field, shapes)
            }
            val plan = found
                ?: throw BotFinish("Игра окончена: ни одна фигура не помещается. Сыграно ходов: $moveNo.")
            BotLog.add("Фигуры: ${shapes.joinToString(" ")} | план: ${plan.moves.joinToString("; ")}")

            // 4) ходы по одному, после каждого проверка по снимку: фигура правда встала?
            val predictedNext = field.copyOf()
            var imgBefore = lastImg
            try {
                for ((idx, mv) in plan.moves.withIndex()) {
                    checkpoint()
                    status("Ход ${moveNo + 1} · фигура ${idx + 1}/${plan.moves.size}")
                    when (playMove(hand[mv.piece], mv, shapes[mv.piece], predictedNext, imgBefore)) {
                        MoveResult.LANDED -> {
                            applyMove(predictedNext, shapes[mv.piece], mv)
                            imgBefore = lastImg
                        }
                        MoveResult.ELSEWHERE -> {
                            moveNo++
                            BotState.moves.value = moveNo
                            throw Reaim()
                        }
                        MoveResult.FAILED -> throw Reaim()
                    }
                    moveNo++
                    BotState.moves.value = moveNo
                    if (limit > 0 && moveNo >= limit) throw BotFinish("Достигнут лимит ходов ($limit).")
                    delay(d(prefs.moveDelayMs.toLong()))
                }
            } catch (e: Reaim) {
                reaims++
                if (reaims >= 8) {
                    throw BotError(
                        "Фигуры не встают на поле. Проверьте, нет ли окон поверх игры, и задайте смещение пальца вручную в «Настройках».",
                    )
                }
                BotLog.add("Пересчитываю по реальному полю ($reaims/8)")
                rd = readStable(1500L)
                continue
            } catch (e: Replan) {
                replans++
                if (replans >= 2) {
                    throw BotError("Жесты несколько раз подряд отменяются системой. Закройте окна поверх игры и попробуйте снова.")
                }
                BotLog.add("3 отмены жеста подряд: внеочередной снимок и пересчёт")
                rd = readStable(1500L)
                continue
            }
            replans = 0
            reaims = 0
            avoidRows = null
            round = RoundRecord(solver.n, field.copyOf(), plan.moves, shapes, predictedNext)

            // 5) ждём новый набор фигур
            status("Жду новые фигуры…")
            delay(d(300L))
            rd = readStable(3500L)
        }
    }

    // ═════════════════════════ Калибровка ═════════════════════════

    private fun loadOffset() {
        if (prefs.useManualOffset) {
            offX = prefs.manualOffX
            offY = prefs.manualOffY
            offsetKnown = true
        } else if (prefs.offsetKnown) {
            offX = prefs.offX
            offY = prefs.offY
            offsetKnown = true
        }
    }

    /** Находит поле и цвета по первому снимку, затем читает стабильный первый набор фигур. */
    private suspend fun calibrate(): Reading {
        status("Калибровка поля…")
        for (attempt in 1..8) {
            checkpoint()
            val img = shot()
            val ignore = overlay.rect
            var geom: Geometry? = null
            var thr = 14
            if (prefs.useManualGeom) {
                geom = prefs.manualGeom()
            } else {
                val f = Vision.detectGrid(img, ignore)
                if (f != null) {
                    geom = f.geometry()
                    thr = f.thr
                    BotLog.add(
                        "Поле ${f.n}×${f.n}: x=${f.x0.toInt()} y=${f.y0.toInt()} клетка=${f.cw.toInt()}×${f.ch.toInt()} px, " +
                            "качество=${"%.2f".format(f.score)}",
                    )
                }
            }
            if (geom != null) {
                val c = Vision.calibrateColors(img, geom, ignore, thr)
                if (c != null) {
                    cal = c
                    solver = Solver(geom.n)
                    BotLog.add(
                        "Пустая клетка: #%06X, порог занятости: %.0f".format(c.emptyColor and 0xFFFFFF, c.threshold),
                    )
                    break
                }
            }
            BotLog.add("Поле не найдено (попытка $attempt/8)")
            delay(1500L)
        }
        if (!::cal.isInitialized) {
            throw BotError(
                "Не удалось автоматически найти игровое поле. Откройте игровой режим (поле с клетками должно быть на экране) " +
                    "и нажмите «Старт». Запасной вариант: «Настройки» → «Ручная калибровка поля».",
            )
        }
        val rd = readStable(3500L)
        if (rd.pieces.isNotEmpty()) {
            val avgCell = rd.pieces.map { it.cellPx }.average().toFloat()
            ratio = avgCell / cal.geom.cell
            prefs.pieceRatio = ratio
        }
        BotLog.add("Первый набор: ${rd.pieces.joinToString(" ") { it.shape.toString() }}")
        return rd
    }

    /**
     * Первый ход как калибровка смещения пальца: безопасная фигура ближе к центру поля, один контрольный
     * снимок сразу после drag, по нему находим, куда фигура реально встала, и считаем поправку.
     */
    private suspend fun calibrateOffset(rd: Reading, field: IntArray): Reading {
        val candidates = listOf(3.0f, 2.5f, 3.5f, 2.0f, 4.0f, 1.5f, 1.0f, 0.5f, 0f)
        var cur = rd
        var curField = field
        var unknown = 0
        BotLog.add("Поле перед калибровкой (# занято, . пусто):")
        logBoard(curField)
        for ((idx, candY) in candidates.withIndex()) {
            val shapes = cur.pieces.map { it.shape }
            val mv = solver.safeMove(curField, shapes)
                ?: throw BotFinish("Игра окончена: ни одна фигура не помещается.")
            offX = 0f
            offY = candY
            val before = lastImg
            val trayBefore = cur.pieces.size
            status("Калибровка пальца (${idx + 1}/${candidates.size})…")
            BotLog.add("Калибровка: пробный ход ${mv}, смещение Y=${candY}")
            if (!dragWithRetry(cur.pieces[mv.piece], mv)) {
                throw BotError("Жесты отменяются системой. Закройте окна поверх игры и попробуйте снова.")
            }
            delay(d(1200L))
            val after = readStable(600L)
            val afterImg = lastImg
            val afterField = resolve(after, null)

            // главный способ: сравнение снимков до/после по клеткам (не зависит от «цвета пустой клетки»)
            var l: Landing = Landing.Unknown
            var changed = -1
            if (before != null && afterImg != null) {
                val ch = changedCells(before, afterImg, cal.geom)
                changed = 0
                for (row in ch) for (v in row) if (v) changed++
                l = locateByDiff(ch, shapes[mv.piece])
            }
            BotLog.add("После хода: фигур в слоте ${after.pieces.size} (было $trayBefore), изменилось клеток поля: $changed")
            // запасной способ: по распознанной занятости клеток
            if (l is Landing.Unknown) l = locate(curField, afterField, shapes[mv.piece])
            // клетки не изменились, но фигура пропала из слота: она где-то встала, место неизвестно
            if (l is Landing.NoChange && after.pieces.size < trayBefore) l = Landing.Unknown

            when (val res = l) {
                is Landing.At -> {
                    val dr = res.row - mv.row
                    val dc = res.col - mv.col
                    offX = -dc.toFloat()
                    offY = candY - dr
                    if (!prefs.useManualOffset) {
                        prefs.saveOffset(offX, offY)
                    }
                    offsetKnown = true
                    moveNo++
                    BotState.moves.value = moveNo
                    BotLog.add("Фигура встала со сдвигом ($dr, $dc) клеток; смещение пальца: X=%.2f Y=%.2f".format(offX, offY))
                    return after
                }
                Landing.NoChange -> {
                    BotLog.add("Фигура не встала на поле (вернулась в слот): пробую другое смещение")
                    cur = after
                    curField = afterField
                }
                Landing.Unknown -> {
                    unknown++
                    BotLog.add("Фигура встала, но место определить не удалось ($unknown/2)")
                    if (unknown >= 2) {
                        throw BotError(
                            "Не удалось определить, куда встала фигура. Задайте смещение пальца вручную в «Настройках».",
                        )
                    }
                    cur = after
                    curField = afterField
                }
            }
        }
        throw BotError("Не удалось подобрать смещение пальца. Задайте его вручную в «Настройках».")
    }

    /** Где оказалась фигура, по клеткам, изменившимся между снимками. */
    private fun locateByDiff(ch: Array<BooleanArray>, s: Shape): Landing {
        val n = ch.size
        var total = 0
        for (r in 0 until n) for (c in 0 until n) if (ch[r][c]) total++
        if (total == 0) return Landing.NoChange
        var bestR = -1
        var bestC = -1
        var bestScore = Int.MIN_VALUE
        for (r in 0..(n - s.h)) {
            for (c in 0..(n - s.w)) {
                var inside = 0
                for (i in 0 until s.h) {
                    for (j in 0 until s.w) {
                        if (((s.rows[i] shr j) and 1) == 1 && ch[r + i][c + j]) inside++
                    }
                }
                val outside = total - inside
                if (inside == s.cells && outside <= 2) {
                    val sc = -outside
                    if (sc > bestScore) {
                        bestScore = sc
                        bestR = r
                        bestC = c
                    }
                }
            }
        }
        return if (bestR >= 0) Landing.At(bestR, bestC) else Landing.Unknown
    }

    private fun logBoard(rows: IntArray) {
        val n = rows.size
        for (r in 0 until n) {
            val sb = StringBuilder()
            for (c in 0 until n) sb.append(if (((rows[r] shr c) and 1) == 1) '#' else '.')
            BotLog.add(sb.toString())
        }
    }

    private fun adjustOffset(dr: Int, dc: Int) {
        if (prefs.useManualOffset) return
        var sx = -dc.toFloat()
        var sy = -dr.toFloat()
        // если поправка противоположна предыдущей, мы на границе клетки: шагаем вдвое меньше (против колебаний)
        if (sx != 0f) {
            if (lastAdjX != 0f && sign(sx) != sign(lastAdjX)) sx *= 0.5f
            lastAdjX = sx
        }
        if (sy != 0f) {
            if (lastAdjY != 0f && sign(sy) != sign(lastAdjY)) sy *= 0.5f
            lastAdjY = sy
        }
        offX += sx
        offY += sy
        prefs.saveOffset(offX, offY)
        BotLog.add("Новое смещение пальца: X=%.2f Y=%.2f".format(offX, offY))
    }

    // ═════════════════════════ Чтение экрана ═════════════════════════

    private suspend fun shot(): Img {
        val wait = 350L - (SystemClock.elapsedRealtime() - lastShotAt)
        if (wait > 0) delay(wait)
        val bmp = overlay.hidden { capturer.grab() }
        lastShotAt = SystemClock.elapsedRealtime()
        try {
            screenW = bmp.width
            screenH = bmp.height
            if (prefs.debugFrames) saveDebug(bmp)
            val img = Img.from(bmp)
            if (Vision.isBlack(img)) {
                throw BotError(
                    "Снимок экрана чёрный: игра или система запретили запись (FLAG_SECURE) либо нет разрешения на запись экрана. " +
                        "Бот не сможет играть.",
                )
            }
            return img
        } finally {
            bmp.recycle()
        }
    }

    private suspend fun readOnce(): Reading {
        val img = shot()
        lastImg = img
        return Vision.analyze(img, cal, overlay.rect, ratio)
    }

    /**
     * Ждёт стабильный кадр: два последовательных снимка совпадают по полю и фигурам.
     * Нормально — 3 фигуры; 1–2 фигуры принимаются после partialAfterMs (часть жестов не сработала).
     * Если за ~6,5 с ничего не вышло — пауза с сообщением (реклама, окно, конец игры).
     */
    private suspend fun readStable(partialAfterMs: Long): Reading {
        var start = SystemClock.elapsedRealtime()
        var prev: Reading? = null
        var stable = 0
        while (true) {
            checkpoint()
            val rd = readOnce()
            val p = prev
            stable = if (p != null && Vision.same(p, rd, cal.geom.cell)) stable + 1 else 0
            prev = rd
            val elapsed = SystemClock.elapsedRealtime() - start
            if (rd.valid) {
                val cnt = rd.pieces.size
                if (stable >= 1 && cnt == 3) return rd
                if (stable >= 2 && cnt in 1..2 && elapsed >= partialAfterMs) return rd
            }
            if (elapsed > 6500L) {
                val why = when {
                    !rd.valid -> "Не вижу игровое поле"
                    rd.pieces.isEmpty() -> "Не появились новые фигуры"
                    else -> "Фигуры распознаются нестабильно"
                }
                pauseFor("$why (реклама, окно или конец игры?). Закройте окно и нажмите «Продолжить».")
                if (!rd.valid) reDetect()
                start = SystemClock.elapsedRealtime()
                prev = null
                stable = 0
            }
            delay(470L)
        }
    }

    /** После паузы раскладка могла измениться: заново ищем сетку. */
    private suspend fun reDetect() {
        if (prefs.useManualGeom) return
        val img = shot()
        val f = Vision.detectGrid(img, overlay.rect) ?: return
        val g = f.geometry()
        val c = Vision.calibrateColors(img, g, overlay.rect, f.thr) ?: return
        cal = c
        solver = Solver(g.n)
        BotLog.add("Поле найдено заново: ${g.n}×${g.n}")
    }

    private fun resolve(rd: Reading, predicted: IntArray?): IntArray {
        val n = cal.geom.n
        val rows = IntArray(n)
        for (r in 0 until n) {
            var m = 0
            for (c in 0 until n) {
                val v = rd.field[r][c]
                val bit = when {
                    v >= 0 -> v
                    predicted != null -> (predicted[r] shr c) and 1
                    else -> 0
                }
                if (bit == 1) m = m or (1 shl c)
            }
            rows[r] = m
        }
        return rows
    }

    // ═════════════════════════ Проверка предсказаний ═════════════════════════

    private fun locate(before: IntArray, after: IntArray, s: Shape): Landing {
        val n = before.size
        var added = 0
        var removed = 0
        for (r in 0 until n) {
            added += Integer.bitCount(after[r] and before[r].inv())
            removed += Integer.bitCount(before[r] and after[r].inv())
        }
        if (added == 0 && removed == 0) return Landing.NoChange
        if (removed == 0 && added == s.cells) {
            for (r in 0..(n - s.h)) {
                for (c in 0..(n - s.w)) {
                    var ok = true
                    for (i in 0 until s.h) {
                        val got = after[r + i] and before[r + i].inv()
                        if ((s.rows[i] shl c) != got) {
                            ok = false
                            break
                        }
                    }
                    if (ok) return Landing.At(r, c)
                }
            }
        }
        return Landing.Unknown
    }

    private fun verify(rec: RoundRecord, actual: IntArray): Verdict {
        if (rec.predicted.contentEquals(actual)) return Verdict.Match
        val n = rec.n
        val tmp = IntArray(n)
        // гипотеза: все ходы раунда сдвинуты на одно и то же число клеток
        for (dr in -2..2) {
            for (dc in -2..2) {
                if (dr == 0 && dc == 0) continue
                val cur = rec.startRows.copyOf()
                var ok = true
                for (mv in rec.moves) {
                    val lines = Board.place(cur, n, rec.shapes[mv.piece], mv.row + dr, mv.col + dc, tmp)
                    if (lines < 0) {
                        ok = false
                        break
                    }
                    System.arraycopy(tmp, 0, cur, 0, n)
                }
                if (ok && cur.contentEquals(actual)) return Verdict.Shift(dr, dc)
            }
        }
        return Verdict.Mismatch
    }

    private fun applyMove(rows: IntArray, s: Shape, mv: Move) {
        val tmp = IntArray(rows.size)
        if (Board.place(rows, rows.size, s, mv.row, mv.col, tmp) >= 0) {
            System.arraycopy(tmp, 0, rows, 0, rows.size)
        }
    }

    // ═════════════════════════ Жесты ═════════════════════════

    /**
     * Старт: центр фигуры в слоте. Финиш: центр фигуры над целевыми клетками с учётом смещения пальца
     * (при смещении 0 верхняя левая клетка фигуры оказывается в центре целевой клетки).
     */
    private suspend fun dragMove(piece: PieceRead, mv: Move, shape: Shape = piece.shape): Boolean {
        val g = cal.geom
        val tx = g.x0 + (mv.col + shape.w / 2f) * g.cw + offX * g.cw
        val ty = g.y0 + (mv.row + shape.h / 2f) * g.ch + offY * g.ch
        val x2 = tx.coerceIn(2f, screenW - 3f)
        val y2 = ty.coerceIn(2f, screenH - 3f)
        BotLog.add(
            "drag (${piece.startX.toInt()},${piece.startY.toInt()}) → (${x2.toInt()},${y2.toInt()}), " +
                "клетка ${mv.row + 1}:${mv.col + 1}",
        )
        return dragHeld(piece.startX, piece.startY, x2, y2, dragDuration(), d(110L), d(200L))
    }

    /**
     * Один ход с проверкой по снимкам: фигура правда встала туда, куда надо?
     * LANDED — поле изменилось ровно так, как ожидалось; ELSEWHERE — изменилось иначе (встала не туда,
     * очистка линии с анимацией, всплывающий текст): нужен свежий снимок и пересчёт; FAILED — фигура
     * ни при одной пробе не встала (возвращалась в слот): эти клетки временно считаем занятыми.
     */
    private suspend fun playMove(
        piece: PieceRead,
        mv: Move,
        shape: Shape,
        rowsBefore: IntArray,
        imgBefore: Img?,
    ): MoveResult {
        val baseX = offX
        val baseY = offY
        if (imgBefore == null) {
            if (!dragWithRetry(piece, mv)) throw Replan()
            return MoveResult.LANDED
        }
        val expected = rowsBefore.copyOf()
        applyMove(expected, shape, mv)
        val tries = floatArrayOf(0f, 0.5f, -0.5f, 1.0f, -1.0f)
        for (dy in tries) {
            checkpoint()
            offY = baseY + dy
            if (!dragWithRetry(piece, mv)) {
                offY = baseY
                throw Replan()
            }
            delay(d(650L))
            var img = shot()
            var mask = changedCells(imgBefore, img, cal.geom)
            var total = 0
            for (row in mask) for (v in row) if (v) total++
            lastImg = img
            if (total == 0) {
                BotLog.add("Фигура не встала на поле (поле не изменилось), смещение Y=%.1f".format(offY))
                continue
            }
            var bad = maskMismatch(mask, rowsBefore, expected)
            if (bad > 2) {
                // возможно, ещё идёт анимация или висит всплывающий текст: смотрим второй раз
                delay(d(600L))
                img = shot()
                mask = changedCells(imgBefore, img, cal.geom)
                bad = maskMismatch(mask, rowsBefore, expected)
                lastImg = img
            }
            if (bad <= 2) {
                if (dy != 0f && !prefs.useManualOffset) {
                    prefs.saveOffset(offX, offY)
                    BotLog.add("Фигура встала при смещении Y=%.1f: запоминаю".format(offY))
                }
                return MoveResult.LANDED
            }
            val l = locateByDiff(mask, shape)
            if (l is Landing.At) {
                val dr = l.row - mv.row
                val dc = l.col - mv.col
                BotLog.add("Фигура встала со сдвигом ($dr, $dc) клеток: поправляю смещение пальца")
                if (!prefs.useManualOffset) {
                    offX = baseX - dc
                    offY = baseY + dy - dr
                    prefs.saveOffset(offX, offY)
                } else {
                    offX = baseX
                    offY = baseY
                }
            } else {
                BotLog.add("Поле изменилось не так, как ожидалось (расхождение $bad клеток)")
                offX = baseX
                offY = baseY
            }
            return MoveResult.ELSEWHERE
        }
        offX = baseX
        offY = baseY
        BotLog.add("Фигура ни разу не встала на поле: считаю эти клетки недоступными и пересчитываю")
        val n = cal.geom.n
        val a = avoidRows ?: IntArray(n)
        for (i in 0 until shape.h) {
            val r = mv.row + i
            if (r in 0 until n) a[r] = a[r] or (shape.rows[i] shl mv.col)
        }
        avoidRows = a
        return MoveResult.FAILED
    }

    /** Сколько клеток маски изменений не совпадает с ожидаемой (клетки под плавающим меню пропускаем). */
    private fun maskMismatch(mask: Array<BooleanArray>, before: IntArray, expected: IntArray): Int {
        val g = cal.geom
        val ign = overlay.rect
        var bad = 0
        for (r in 0 until g.n) {
            for (c in 0 until g.n) {
                if (ign != null && ign.contains(g.cx(c).toInt(), g.cy(r).toInt())) continue
                val exp = (((before[r] xor expected[r]) shr c) and 1) == 1
                if (mask[r][c] != exp) bad++
            }
        }
        return bad
    }

    /** Клетки поля, цвет которых заметно изменился между двумя снимками (не зависит от «цвета пустой клетки»). */
    private fun changedCells(before: Img, after: Img, g: Geometry): Array<BooleanArray> {
        val res = Array(g.n) { BooleanArray(g.n) }
        if (before.w != after.w || before.h != after.h) return res
        val ign = overlay.rect
        val half = maxOf(2, (0.2f * g.cell).toInt())
        for (r in 0 until g.n) {
            for (c in 0 until g.n) {
                val x = g.cx(c)
                val y = g.cy(r)
                if (ign != null && ign.contains(x.toInt(), y.toInt())) continue
                if (dist(Vision.avg(before, x, y, half), Vision.avg(after, x, y, half)) > 40f) res[r][c] = true
            }
        }
        return res
    }

    /** Отправляет один жест и ждёт результата. false — жест отменён или не отправлен. */
    private suspend fun dispatchStroke(stroke: GestureDescription.StrokeDescription): Boolean =
        suspendCancellableCoroutine { cont ->
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val callback = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }
            val sent = try {
                svc.dispatchGesture(gesture, callback, null)
            } catch (t: Throwable) {
                false
            }
            if (!sent && cont.isActive) cont.resume(false)
        }

    private fun pointPath(x: Float, y: Float): Path {
        val p = Path()
        p.moveTo(x, y)
        return p
    }

    /**
     * Перетаскивание с паузами: прижали палец на фигуре (pressMs), повели к цели (durationMs),
     * подержали на цели (holdMs) и отпустили. На Android 7 и ниже — обычный drag без пауз.
     */
    private suspend fun dragHeld(
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        durationMs: Long,
        pressMs: Long,
        holdMs: Long,
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return svc.drag(x1, y1, x2, y2, durationMs)
        return dragHeldO(x1, y1, x2, y2, durationMs, pressMs, holdMs)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private suspend fun dragHeldO(
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        durationMs: Long,
        pressMs: Long,
        holdMs: Long,
    ): Boolean {
        val move = Path()
        move.moveTo(x1, y1)
        val steps = 8
        for (i in 1 until steps) {
            val t = i / steps.toFloat()
            move.lineTo(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)
        }
        move.lineTo(x2, y2) // конец пути точно в цели, без погрешности float
        val press = GestureDescription.StrokeDescription(pointPath(x1, y1), 0L, pressMs.coerceAtLeast(1L), true)
        var down: GestureDescription.StrokeDescription = press // последний отрезок: палец ещё прижат
        var downX = x1
        var downY = y1
        try {
            if (!dispatchStroke(press)) return false
            val moving = press.continueStroke(move, 0L, durationMs.coerceAtLeast(50L), true)
            down = moving
            downX = x2
            downY = y2
            if (!dispatchStroke(moving)) return false
            val hold = moving.continueStroke(pointPath(x2, y2), 0L, holdMs.coerceAtLeast(1L), false)
            return dispatchStroke(hold)
        } catch (e: CancellationException) {
            // «Стоп» посреди жеста: обязательно отпускаем палец, иначе касание может «залипнуть»
            try {
                withContext(NonCancellable) {
                    dispatchStroke(down.continueStroke(pointPath(downX, downY), 0L, 1L, false))
                }
            } catch (t: Throwable) {
                // отпустить не вышло — система сама снимет касание
            }
            throw e
        }
    }

    /** Если жест отменён (onCancelled) — повторяем до 3 раз. */
    private suspend fun dragWithRetry(piece: PieceRead, mv: Move): Boolean {
        repeat(3) { attempt ->
            if (dragMove(piece, mv)) return true
            BotLog.add("Жест отменён (${attempt + 1}/3)")
            delay(200L)
        }
        return false
    }

    // ═════════════════════════ Пауза и передний план ═════════════════════════

    private suspend fun pauseFor(msg: String) {
        BotLog.add(msg)
        BotState.status.value = msg
        BotState.paused.value = true
        BotState.paused.first { !it }
        BotState.status.value = "Продолжаю…"
    }

    /** Перед каждым снимком и жестом: пауза пользователя и проверка, что игра на переднем плане. */
    private suspend fun checkpoint() {
        while (true) {
            if (BotState.paused.value) {
                BotState.paused.first { !it }
                continue
            }
            if (BotAccessibilityService.foregroundPackage.value != gamePkg) {
                BotLog.add("Игра не на переднем плане: жду, пока вы её откроете")
                status("Откройте игру — бот продолжит сам")
                BotAccessibilityService.foregroundPackage.first { it == gamePkg }
                BotLog.add("Игра снова на переднем плане")
                delay(800L)
                continue
            }
            return
        }
    }

    // ═════════════════════════ Отладка ═════════════════════════

    private fun saveDebug(bmp: Bitmap) {
        try {
            val dir = File(ctx.filesDir, "debug")
            dir.mkdirs()
            val f = File(dir, "frame_${System.currentTimeMillis()}.png")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) }
            dir.listFiles()?.sortedBy { it.lastModified() }?.dropLast(30)?.forEach { it.delete() }
        } catch (t: Throwable) {
            // отладочные кадры необязательны
        }
    }
}
