package com.blockbot.auto.solver

import kotlin.math.sqrt

/**
 * Чистый Kotlin-модуль решателя: без зависимостей от Android.
 * Поле N×N хранится как IntArray: rows[i] — битовая маска строки i (бит j = столбец j, 1 = занято).
 */

/** Фигура. rows[i] — битовая маска i-й строки (бит j = столбец j). Вращать фигуры нельзя. */
class Shape(val h: Int, val w: Int, val rows: IntArray) {
    val cells: Int = rows.sumOf { Integer.bitCount(it) }

    fun filled(i: Int, j: Int): Boolean = ((rows[i] shr j) and 1) == 1

    override fun equals(other: Any?): Boolean =
        other is Shape && other.h == h && other.w == w && other.rows.contentEquals(rows)

    override fun hashCode(): Int = 31 * (31 * h + w) + rows.contentHashCode()

    override fun toString(): String = (0 until h).joinToString("/") { i ->
        (0 until w).joinToString("") { j -> if (filled(i, j)) "#" else "." }
    }

    companion object {
        fun fromMask(mask: Array<BooleanArray>): Shape {
            val h = mask.size
            val w = mask[0].size
            val rows = IntArray(h) { i ->
                var m = 0
                for (j in 0 until w) if (mask[i][j]) m = m or (1 shl j)
                m
            }
            return Shape(h, w, rows)
        }

        /** Для тестов: Shape.parse("##", "#.") */
        fun parse(vararg lines: String): Shape {
            val h = lines.size
            val w = lines[0].length
            val rows = IntArray(h) { i ->
                var m = 0
                for (j in 0 until w) if (lines[i][j] == '#') m = m or (1 shl j)
                m
            }
            return Shape(h, w, rows)
        }
    }
}

/** Ход: индекс фигуры, строка и столбец её верхнего левого угла, число очищенных линий. */
class Move(val piece: Int, val row: Int, val col: Int, val lines: Int) {
    override fun toString(): String =
        "фигура ${piece + 1} → ряд ${row + 1}, столбец ${col + 1}" + (if (lines > 0) " (линий: $lines)" else "")
}

/** План: упорядоченные ходы, итоговое поле и оценка. */
class Plan(val moves: List<Move>, val finalRows: IntArray, val score: Double)

/** Веса оценки позиции. Все значения подобраны эмпирически и меняются в одном месте. */
data class Weights(
    /** Награда за каждую очищенную линию. */
    val line: Double = 40.0,
    /** Добавка за комбо: за k линий одним ходом + combo * k * (k - 1). */
    val combo: Double = 30.0,
    /** Награда за каждую свободную клетку в конце. */
    val free: Double = 1.5,
    /** Если свободных клеток меньше этого порога, начинается штраф. */
    val lowFreeLimit: Int = 14,
    /** Штраф за каждую недостающую свободную клетку ниже порога. */
    val lowFree: Double = 6.0,
    /** Штраф за «дырку» (свободная клетка, окружённая занятыми со всех 4 сторон). */
    val hole: Double = 35.0,
    /** Штраф за изрезанность границы (число переходов занято/свободно по строкам и столбцам). */
    val transition: Double = 2.0,
    /** Награда за каждое место под фигуру 3×3 (с ограничением). */
    val big33: Double = 3.0,
    val big33Cap: Int = 6,
    /** Награда за каждое место под линию 1×5 или 5×1 (с ограничением). */
    val big5: Double = 2.0,
    val big5Cap: Int = 8,
    /** Награда за каждую клетку самой большой связной свободной области. */
    val region: Double = 0.8,
    /** Штраф за каждую клетку в крошечных (до 3 клеток) изолированных свободных областях. */
    val tiny: Double = 4.0,
)

object Board {
    fun fullMask(n: Int): Int = (1 shl n) - 1

    fun canPlace(rows: IntArray, n: Int, s: Shape, r: Int, c: Int): Boolean {
        if (r < 0 || c < 0 || r + s.h > n || c + s.w > n) return false
        for (i in 0 until s.h) {
            if ((rows[r + i] and (s.rows[i] shl c)) != 0) return false
        }
        return true
    }

    /**
     * Ставит фигуру в out (rows не меняется) и очищает линии.
     * Возвращает число очищенных линий или -1, если поставить нельзя.
     */
    fun place(rows: IntArray, n: Int, s: Shape, r: Int, c: Int, out: IntArray): Int {
        if (!canPlace(rows, n, s, r, c)) return -1
        System.arraycopy(rows, 0, out, 0, n)
        for (i in 0 until s.h) out[r + i] = out[r + i] or (s.rows[i] shl c)
        return clearLines(out, n)
    }

    /** Сначала находит ВСЕ полные строки и столбцы, затем очищает их одновременно. */
    fun clearLines(rows: IntArray, n: Int): Int {
        val full = fullMask(n)
        var colFull = full
        var rowCount = 0
        var fullRows = 0
        for (i in 0 until n) {
            colFull = colFull and rows[i]
            if (rows[i] == full) {
                rowCount++
                fullRows = fullRows or (1 shl i)
            }
        }
        if (rowCount == 0 && colFull == 0) return 0
        val keep = full and colFull.inv()
        for (i in 0 until n) {
            rows[i] = if (((fullRows shr i) and 1) == 1) 0 else (rows[i] and keep)
        }
        return rowCount + Integer.bitCount(colFull)
    }
}

class Solver(val n: Int, private val w: Weights = Weights()) {
    private val full = Board.fullMask(n)

    init {
        require(n in 4..12) { "Размер поля должен быть от 4 до 12" }
    }

    /**
     * Полный перебор: все порядки фигур × все допустимые позиции, очистка линий после каждого хода.
     * Если ставятся не все фигуры, выбирается последовательность с максимумом поставленных,
     * затем лучшая по оценке. Если не помещается ничего — null (конец игры).
     */
    fun solve(rows: IntArray, pieces: List<Shape>, budgetMs: Long = 2500L): Plan? {
        if (pieces.isEmpty()) return null
        return Search(rows, pieces, budgetMs).run()
    }

    /**
     * Безопасный первый ход для калибровки смещения пальца: без очистки линий
     * (чтобы однозначно определить, куда встала фигура), ближе к центру поля.
     */
    fun safeMove(rows: IntArray, pieces: List<Shape>): Move? {
        val tmp = IntArray(n)
        var best: Move? = null
        var bestScore = -1e18
        var any: Move? = null
        var anyScore = -1e18
        for ((pi, s) in pieces.withIndex()) {
            for (r in 0..(n - s.h)) {
                for (c in 0..(n - s.w)) {
                    val lines = Board.place(rows, n, s, r, c, tmp)
                    if (lines < 0) continue
                    val dy = r + s.h / 2.0 - n / 2.0
                    val dx = c + s.w / 2.0 - n / 2.0
                    val sc = cheapEval(tmp) - 6.0 * sqrt(dx * dx + dy * dy)
                    if (lines == 0) {
                        if (sc > bestScore) {
                            bestScore = sc
                            best = Move(pi, r, c, 0)
                        }
                    } else if (sc > anyScore) {
                        anyScore = sc
                        any = Move(pi, r, c, lines)
                    }
                }
            }
        }
        return best ?: any
    }

    fun lineScore(lines: Int): Double =
        if (lines <= 0) 0.0 else w.line * lines + w.combo * lines * (lines - 1)

    /** Быстрая оценка на битовых операциях (используется в переборе). */
    fun cheapEval(rows: IntArray): Double {
        var filled = 0
        var trans = 0
        var holes = 0
        val edgeMask = (1 shl (n + 1)) - 1
        for (r in 0 until n) {
            val row = rows[r]
            filled += Integer.bitCount(row)
            // горизонтальные переходы; стены считаются занятыми
            val e = (row shl 1) or 1 or (1 shl (n + 1))
            trans += Integer.bitCount((e xor (e shr 1)) and edgeMask)
            val up = if (r == 0) full else rows[r - 1]
            val down = if (r == n - 1) full else rows[r + 1]
            trans += Integer.bitCount(row xor up)
            // «дырки»: свободная клетка, у которой все 4 соседа заняты
            val left = ((row shl 1) or 1) and full
            val right = ((row shr 1) or (1 shl (n - 1))) and full
            holes += Integer.bitCount((row.inv() and full) and left and right and up and down)
        }
        trans += Integer.bitCount(rows[n - 1] xor full)
        val free = n * n - filled
        var s = w.free * free - w.transition * trans - w.hole * holes
        if (free < w.lowFreeLimit) s -= w.lowFree * (w.lowFreeLimit - free)
        s += w.big33 * minOf(w.big33Cap, count3x3(rows)) + w.big5 * minOf(w.big5Cap, count5(rows))
        return s
    }

    /** Полная оценка: быстрая + анализ связных свободных областей (для лучших кандидатов). */
    fun fullEval(rows: IntArray): Double {
        var s = cheapEval(rows)
        val seen = BooleanArray(n * n)
        val stack = IntArray(n * n)
        var largest = 0
        var tiny = 0
        for (start in 0 until n * n) {
            if (seen[start] || isOccupied(rows, start)) continue
            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var size = 0
            while (sp > 0) {
                val cur = stack[--sp]
                size++
                val r = cur / n
                val c = cur % n
                if (r > 0 && !seen[cur - n] && !isOccupied(rows, cur - n)) { seen[cur - n] = true; stack[sp++] = cur - n }
                if (r < n - 1 && !seen[cur + n] && !isOccupied(rows, cur + n)) { seen[cur + n] = true; stack[sp++] = cur + n }
                if (c > 0 && !seen[cur - 1] && !isOccupied(rows, cur - 1)) { seen[cur - 1] = true; stack[sp++] = cur - 1 }
                if (c < n - 1 && !seen[cur + 1] && !isOccupied(rows, cur + 1)) { seen[cur + 1] = true; stack[sp++] = cur + 1 }
            }
            if (size > largest) largest = size
            if (size <= 3) tiny += size
        }
        s += w.region * largest - w.tiny * tiny
        return s
    }

    private fun isOccupied(rows: IntArray, idx: Int): Boolean = ((rows[idx / n] shr (idx % n)) and 1) == 1

    private fun count3x3(rows: IntArray): Int {
        var cnt = 0
        for (r in 0..(n - 3)) {
            val m = (rows[r] or rows[r + 1] or rows[r + 2]).inv() and full
            cnt += Integer.bitCount(m and (m shr 1) and (m shr 2))
        }
        return cnt
    }

    private fun count5(rows: IntArray): Int {
        var cnt = 0
        for (r in 0 until n) {
            val f = rows[r].inv() and full
            cnt += Integer.bitCount(f and (f shr 1) and (f shr 2) and (f shr 3) and (f shr 4))
        }
        if (n >= 5) {
            for (r in 0..(n - 5)) {
                val f = (rows[r] or rows[r + 1] or rows[r + 2] or rows[r + 3] or rows[r + 4]).inv() and full
                cnt += Integer.bitCount(f)
            }
        }
        return cnt
    }

    private fun allPositions(s: Shape): IntArray {
        val list = ArrayList<Int>()
        for (r in 0..(n - s.h)) for (c in 0..(n - s.w)) list.add((r shl 4) or c)
        return list.toIntArray()
    }

    private inner class Search(val start: IntArray, val pieces: List<Shape>, budgetMs: Long) {
        val k = pieces.size
        val deadline = System.nanoTime() + budgetMs * 1_000_000L
        var timeUp = false
        var leafCount = 0L
        val boards = Array(k + 1) { IntArray(n) }
        val pPiece = IntArray(k)
        val pRow = IntArray(k)
        val pCol = IntArray(k)
        val pLines = IntArray(k)
        val positions: Array<IntArray> = Array(k) { allPositions(pieces[it]) }

        // Лучшие K листьев (по быстрой оценке) переоцениваются полной оценкой.
        val topK = 24
        val keys = DoubleArray(topK)
        val paths = Array(topK) { IntArray(4 * k) }
        var size = 0
        var worstIdx = 0
        var worstKey = Double.NEGATIVE_INFINITY

        fun run(): Plan? {
            System.arraycopy(start, 0, boards[0], 0, n)
            val perms = permutations(k).distinctBy { p -> p.map { pieces[it] } }
            for (perm in perms) {
                dfs(perm, 0, 0, 0.0)
                if (timeUp) break
            }
            return if (size == 0) null else pick()
        }

        fun dfs(perm: IntArray, depth: Int, placed: Int, lineSum: Double) {
            if (timeUp) return
            if (depth == k) {
                leaf(placed, lineSum)
                return
            }
            val pi = perm[depth]
            val s = pieces[pi]
            val cur = boards[depth]
            val nxt = boards[depth + 1]
            var any = false
            for (code in positions[pi]) {
                val r = code shr 4
                val c = code and 15
                val lines = Board.place(cur, n, s, r, c, nxt)
                if (lines < 0) continue
                any = true
                pPiece[depth] = pi
                pRow[depth] = r
                pCol[depth] = c
                pLines[depth] = lines
                dfs(perm, depth + 1, placed + 1, lineSum + lineScore(lines))
                if (timeUp) return
            }
            if (!any) {
                // фигура никуда не помещается: пропускаем её и идём дальше
                pPiece[depth] = -1
                System.arraycopy(cur, 0, nxt, 0, n)
                dfs(perm, depth + 1, placed, lineSum)
            }
        }

        fun leaf(placed: Int, lineSum: Double) {
            leafCount++
            if ((leafCount and 0x3FFL) == 0L && System.nanoTime() > deadline) timeUp = true
            val key = placed * 1.0e6 + lineSum + cheapEval(boards[k])
            if (size == topK && key <= worstKey) return
            val idx = if (size < topK) size++ else worstIdx
            keys[idx] = key
            val p = paths[idx]
            for (d in 0 until k) {
                p[4 * d] = pPiece[d]
                p[4 * d + 1] = pRow[d]
                p[4 * d + 2] = pCol[d]
                p[4 * d + 3] = pLines[d]
            }
            var wi = 0
            var wk = keys[0]
            for (i in 1 until size) {
                if (keys[i] < wk) { wk = keys[i]; wi = i }
            }
            worstIdx = wi
            worstKey = wk
        }

        fun pick(): Plan? {
            var bestKey = Double.NEGATIVE_INFINITY
            var best: Plan? = null
            var cur = IntArray(n)
            var nxt = IntArray(n)
            for (e in 0 until size) {
                System.arraycopy(start, 0, cur, 0, n)
                val moves = ArrayList<Move>()
                var lineSum = 0.0
                for (d in 0 until k) {
                    val pi = paths[e][4 * d]
                    if (pi < 0) continue
                    val r = paths[e][4 * d + 1]
                    val c = paths[e][4 * d + 2]
                    val lines = Board.place(cur, n, pieces[pi], r, c, nxt)
                    if (lines < 0) continue
                    moves.add(Move(pi, r, c, lines))
                    lineSum += lineScore(lines)
                    val t = cur; cur = nxt; nxt = t
                }
                if (moves.isEmpty()) continue
                val score = lineSum + fullEval(cur)
                val key = moves.size * 1.0e6 + score
                if (key > bestKey) {
                    bestKey = key
                    best = Plan(moves, cur.copyOf(), score)
                }
            }
            return best
        }
    }

    companion object {
        /** Все перестановки индексов 0..k-1. */
        fun permutations(k: Int): List<IntArray> {
            val res = ArrayList<IntArray>()
            fun rec(cur: IntArray, used: BooleanArray, pos: Int) {
                if (pos == k) {
                    res.add(cur.copyOf())
                    return
                }
                for (i in 0 until k) {
                    if (!used[i]) {
                        used[i] = true
                        cur[pos] = i
                        rec(cur, used, pos + 1)
                        used[i] = false
                    }
                }
            }
            rec(IntArray(k), BooleanArray(k), 0)
            return res
        }
    }
}
