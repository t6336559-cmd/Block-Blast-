package com.blockbot.auto

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Общее состояние бота для интерфейса, меню и сервиса. */
object BotState {
    val running = MutableStateFlow(false)
    val paused = MutableStateFlow(false)
    val status = MutableStateFlow("")
    val message = MutableStateFlow<String?>(null)
    val moves = MutableStateFlow(0)

    fun resetForStart() {
        running.value = true
        paused.value = false
        status.value = "Запуск…"
        message.value = null
        moves.value = 0
    }

    fun togglePause() {
        val p = !paused.value
        paused.value = p
        if (p) status.value = "Пауза"
    }
}

/** Журнал: последние 200 строк. */
object BotLog {
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines.asStateFlow()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun add(msg: String) {
        val line = "${fmt.format(Date())}  $msg"
        android.util.Log.d("BlockBot", msg)
        _lines.update { (it + line).takeLast(200) }
    }

    fun clear() {
        _lines.value = emptyList()
    }
}
