package com.blockbot.auto

/** Ошибка, после которой бот останавливается с понятным сообщением. */
class BotError(message: String) : Exception(message)

/** Штатное завершение (лимит ходов, конец игры). */
class BotFinish(message: String) : Exception(message)
