package com.blockbot.auto

import android.content.Context
import com.blockbot.auto.vision.Geometry

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("blockbot", Context.MODE_PRIVATE)

    var gamePkg: String?
        get() = sp.getString("gamePkg", null)
        set(v) { sp.edit().putString("gamePkg", v).apply() }

    // ── необязательные настройки ──
    var speed: Float
        get() = sp.getFloat("speed", 1f)
        set(v) { sp.edit().putFloat("speed", v).apply() }
    var dragMs: Int
        get() = sp.getInt("dragMs", 320)
        set(v) { sp.edit().putInt("dragMs", v).apply() }
    var moveDelayMs: Int
        get() = sp.getInt("moveDelayMs", 350)
        set(v) { sp.edit().putInt("moveDelayMs", v).apply() }
    var moveLimit: Int
        get() = sp.getInt("moveLimit", 0)
        set(v) { sp.edit().putInt("moveLimit", v).apply() }
    var debugFrames: Boolean
        get() = sp.getBoolean("debugFrames", false)
        set(v) { sp.edit().putBoolean("debugFrames", v).apply() }

    // ── смещение пальца (в клетках поля) ──
    var offsetKnown: Boolean
        get() = sp.getBoolean("offKnown", false)
        set(v) { sp.edit().putBoolean("offKnown", v).apply() }
    var offX: Float
        get() = sp.getFloat("offX", 0f)
        set(v) { sp.edit().putFloat("offX", v).apply() }
    var offY: Float
        get() = sp.getFloat("offY", 1.5f)
        set(v) { sp.edit().putFloat("offY", v).apply() }
    var useManualOffset: Boolean
        get() = sp.getBoolean("useManualOffset", false)
        set(v) { sp.edit().putBoolean("useManualOffset", v).apply() }
    var manualOffX: Float
        get() = sp.getFloat("manualOffX", 0f)
        set(v) { sp.edit().putFloat("manualOffX", v).apply() }
    var manualOffY: Float
        get() = sp.getFloat("manualOffY", 1.5f)
        set(v) { sp.edit().putFloat("manualOffY", v).apply() }

    /** Отношение размера клетки фигуры в слоте к клетке поля (определяется само). */
    var pieceRatio: Float
        get() = sp.getFloat("pieceRatio", 0f)
        set(v) { sp.edit().putFloat("pieceRatio", v).apply() }

    // ── ручная геометрия поля (запасной вариант) ──
    var useManualGeom: Boolean
        get() = sp.getBoolean("useManualGeom", false)
        set(v) { sp.edit().putBoolean("useManualGeom", v).apply() }

    fun saveManualGeom(g: Geometry) {
        sp.edit().putInt("mgN", g.n).putFloat("mgX", g.x0).putFloat("mgY", g.y0)
            .putFloat("mgCw", g.cw).putFloat("mgCh", g.ch).apply()
    }

    fun manualGeom(): Geometry? {
        val n = sp.getInt("mgN", 0)
        if (n < 4) return null
        return Geometry(n, sp.getFloat("mgX", 0f), sp.getFloat("mgY", 0f), sp.getFloat("mgCw", 0f), sp.getFloat("mgCh", 0f))
    }

    fun saveOffset(x: Float, y: Float) {
        sp.edit().putFloat("offX", x).putFloat("offY", y).putBoolean("offKnown", true).apply()
    }

    /** Сброс автокалибровки (смещение и масштаб фигур). */
    fun resetCalibration() {
        sp.edit().putBoolean("offKnown", false).putFloat("offX", 0f).putFloat("offY", 1.5f)
            .putFloat("pieceRatio", 0f).apply()
    }
}
