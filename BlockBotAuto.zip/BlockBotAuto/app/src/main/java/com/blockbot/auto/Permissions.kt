package com.blockbot.auto

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat

/** Токен MediaProjection (только Android 10 и ниже). */
object ProjectionHolder {
    @Volatile var resultCode: Int = 0
    @Volatile var data: Intent? = null
    fun clear() {
        data = null
        resultCode = 0
    }
}

data class PermState(
    val accessibility: Boolean = false,
    val overlay: Boolean = false,
    val notifications: Boolean = true,
    val projection: Boolean = true,
    val battery: Boolean = false,
) {
    /** Все обязательные разрешения выданы. */
    fun required(): Boolean = accessibility && overlay && notifications && projection
}

object Permissions {
    fun needsProjection(): Boolean = Build.VERSION.SDK_INT < 30
    fun projectionGranted(): Boolean = ProjectionHolder.data != null

    fun accessibilityEnabled(ctx: Context): Boolean {
        val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(ctx, BotAccessibilityService::class.java)
        val full = me.flattenToString()
        val short = me.flattenToShortString()
        return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    fun overlayGranted(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun notificationsGranted(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun batteryIgnored(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }

    fun snapshot(ctx: Context) = PermState(
        accessibility = accessibilityEnabled(ctx),
        overlay = overlayGranted(ctx),
        notifications = notificationsGranted(ctx),
        projection = !needsProjection() || projectionGranted(),
        battery = batteryIgnored(ctx),
    )

    fun openAccessibilitySettings(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openOverlaySettings(ctx: Context) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }

    /** Страница приложения: ⋮ → «Разрешить ограниченные настройки» (Android 13+). */
    fun openAppDetails(ctx: Context) {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }

    private val vendorComponents = listOf(
        "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
        "com.samsung.android.lool" to "com.samsung.android.sm.battery.ui.BatteryActivity",
    )

    /** Настройки батареи и автозапуска: пробуем окна производителя, затем общие настройки. */
    fun openBackgroundSettings(ctx: Context) {
        for ((pkg, cls) in vendorComponents) {
            try {
                ctx.startActivity(Intent().setComponent(ComponentName(pkg, cls)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (t: Throwable) {
                // не этот производитель — пробуем следующий
            }
        }
        try {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (t: Throwable) {
            openAppDetails(ctx)
        }
    }
}
