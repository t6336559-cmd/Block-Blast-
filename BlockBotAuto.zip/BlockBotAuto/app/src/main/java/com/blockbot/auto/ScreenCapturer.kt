package com.blockbot.auto

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.delay

/** Источник снимков экрана. Снимки живут только в памяти. */
interface Capturer {
    suspend fun grab(): Bitmap
    fun release()
}

/** Android 11+: снимки через службу специальных возможностей, без диалога. */
class AccessibilityCapturer(private val svc: BotAccessibilityService) : Capturer {
    override suspend fun grab(): Bitmap {
        if (Build.VERSION.SDK_INT < 30) throw BotError("Снимки через службу доступны только на Android 11 и новее.")
        var lastCode = 0
        repeat(8) {
            when (val r = svc.screenshot()) {
                is ShotResult.Ok -> return r.bitmap
                is ShotResult.Fail -> {
                    lastCode = r.code
                    // 3 = слишком частые снимки: ждём и повторяем
                    delay(if (r.code == 3) 400L else 300L)
                }
            }
        }
        throw BotError("Не удалось получить снимок экрана (код $lastCode). Проверьте, что служба специальных возможностей включена.")
    }

    override fun release() {}
}

/** Android 10 и ниже: запись экрана через MediaProjection (ImageReader + VirtualDisplay). */
class ProjectionCapturer(ctx: Context, private val projection: MediaProjection) : Capturer {
    @Suppress("DEPRECATION")
    private val metrics = DisplayMetrics().also {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(it)
    }
    private val width = metrics.widthPixels
    private val height = metrics.heightPixels
    private val thread = HandlerThread("blockbot-capture").also { it.start() }
    private val handler = Handler(thread.looper)
    private val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
    private var display: VirtualDisplay? = null
    private val lock = Any()
    private var latest: Image? = null

    init {
        reader.setOnImageAvailableListener({ r ->
            val img = try {
                r.acquireLatestImage()
            } catch (t: Throwable) {
                null
            }
            if (img != null) {
                synchronized(lock) {
                    latest?.close()
                    latest = img
                }
            }
        }, handler)
        display = projection.createVirtualDisplay(
            "blockbot", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler,
        )
    }

    override suspend fun grab(): Bitmap {
        repeat(30) {
            val bmp = synchronized(lock) { latest?.let { toBitmap(it) } }
            if (bmp != null) return bmp
            delay(100)
        }
        throw BotError("Нет кадров записи экрана. Выдайте разрешение на запись экрана заново.")
    }

    private fun toBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * width
        val full = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
        val buf = plane.buffer
        buf.rewind()
        full.copyPixelsFromBuffer(buf)
        if (rowPadding == 0) return full
        val cropped = Bitmap.createBitmap(full, 0, 0, width, height)
        full.recycle()
        return cropped
    }

    override fun release() {
        try { display?.release() } catch (t: Throwable) { }
        synchronized(lock) {
            latest?.close()
            latest = null
        }
        try { reader.close() } catch (t: Throwable) { }
        try { projection.stop() } catch (t: Throwable) { }
        thread.quitSafely()
    }
}
