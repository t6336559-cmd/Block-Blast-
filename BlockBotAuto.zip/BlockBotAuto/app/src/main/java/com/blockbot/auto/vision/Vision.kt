package com.blockbot.auto.vision

import android.graphics.Bitmap
import android.graphics.Rect
import com.blockbot.auto.solver.Shape
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Снимок экрана в виде массива пикселей ARGB. */
class Img(val w: Int, val h: Int, val px: IntArray) {
    companion object {
        fun from(bmp: Bitmap): Img {
            val w = bmp.width
            val h = bmp.height
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            return Img(w, h, px)
        }
    }
}

/** Геометрия поля на экране (в пикселях). */
class Geometry(val n: Int, val x0: Float, val y0: Float, val cw: Float, val ch: Float) {
    val right: Float get() = x0 + n * cw
    val bottom: Float get() = y0 + n * ch
    val cell: Float get() = (cw + ch) / 2f
    fun cx(col: Int): Float = x0 + (col + 0.5f) * cw
    fun cy(row: Int): Float = y0 + (row + 0.5f) * ch
}

class GridFit(val n: Int, val x0: Float, val y0: Float, val cw: Float, val ch: Float, val score: Float, val thr: Int) {
    fun geometry() = Geometry(n, x0, y0, cw, ch)
}

/** Результат автокалибровки цветов: цвет пустой клетки и порог «занято». */
class Calibration(val geom: Geometry, val emptyColor: Int, val threshold: Float, val edgeThr: Int)

class PieceRead(
    val shape: Shape,
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
    /** Размер клетки самой фигуры в пикселях. */
    val cellPx: Float,
    /** Куда ставить палец в слоте (центр фигуры, внутри закрашенной клетки). */
    val startX: Float,
    val startY: Float,
)

/** field[r][c]: 1 занято, 0 пусто, -1 неизвестно (под плавающим меню). */
class Reading(
    val field: Array<IntArray>,
    val pieces: List<PieceRead>,
    val gridScore: Float,
    val empties: Int,
) {
    val valid: Boolean get() = gridScore >= 0.30f && empties >= 3
}

internal fun cr(c: Int) = (c shr 16) and 255
internal fun cg(c: Int) = (c shr 8) and 255
internal fun cb(c: Int) = c and 255
internal fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
internal fun lum(c: Int): Float = 0.299f * cr(c) + 0.587f * cg(c) + 0.114f * cb(c)
internal fun dist(a: Int, b: Int): Float {
    val dr = cr(a) - cr(b)
    val dg = cg(a) - cg(b)
    val db = cb(a) - cb(b)
    return sqrt((dr * dr + dg * dg + db * db).toFloat())
}

object Vision {

    // ───────────────────────── Поиск сетки ─────────────────────────

    /** Ищет поле N×N (N = 6…10) по периодическим границам клеток. null, если не нашли. */
    fun detectGrid(img: Img, ignore: Rect?): GridFit? {
        var best: GridFit? = null
        for (thr in intArrayOf(28, 16, 10, 6)) {
            val fit = detectWithThreshold(img, thr, ignore) ?: continue
            if (fit.score >= 0.55f) return fit
            val b = best
            if (b == null || fit.score > b.score) best = fit
        }
        val b = best
        return if (b != null && b.score >= 0.40f) b else null
    }

    private fun detectWithThreshold(img: Img, thr: Int, ignore: Rect?): GridFit? {
        val w = img.w
        val h = img.h
        // 1) вертикальные линии по средней части экрана
        val sm0 = smooth(colEdges(img, thr, (h * 0.10f).toInt(), (h * 0.90f).toInt(), ignore), 3)
        var bestScore = -9f
        var bn = 0
        var bc = 0f
        var bx = 0f
        for (n in 6..10) {
            var c = 0.45f * w / n
            val cMax = 1.0f * w / n
            while (c <= cMax) {
                val ref = 0.5f * n * c
                val maxX0 = (w - n * c).toInt()
                for (x0 in 0..maxX0) {
                    val s = combScore(sm0, x0.toFloat(), c, n, ref)
                    if (s > bestScore) {
                        bestScore = s; bn = n; bc = c; bx = x0.toFloat()
                    }
                }
                c += 0.5f
            }
        }
        if (bn == 0 || bestScore < 0.25f) return null

        // 2) горизонтальные линии только внутри найденных столбцов
        val xr0 = bx.toInt()
        val xr1 = min(w - 1, (bx + bn * bc).toInt())
        val smR = smooth(rowEdges(img, thr, xr0, xr1, ignore), 3)
        var bestY = -9f
        var by = 0f
        var bcy = bc
        var f = 0.96f
        while (f <= 1.04f) {
            val cy = bc * f
            val ref = 0.5f * bn * cy
            val maxY0 = (h - bn * cy).toInt()
            for (y0 in 0..maxY0) {
                val s = combScore(smR, y0.toFloat(), cy, bn, ref)
                if (s > bestY) {
                    bestY = s; by = y0.toFloat(); bcy = cy
                }
            }
            f += 0.005f
        }
        if (bestY < 0.25f) return null

        // 3) вертикальные линии ещё раз, но только в строках поля (чище профиль)
        val yEnd = min(h, (by + bn * bcy).toInt())
        val col1 = colEdges(img, thr, by.toInt(), yEnd, ignore)
        val sm1 = smooth(col1, 3)
        var bs = -9f
        var fx = bx
        var fc = bc
        var df = -0.03f
        while (df <= 0.03f) {
            val c = bc * (1f + df)
            val ref = 0.5f * bn * c
            for (dx in -8..8) {
                val x0 = bx + dx
                val s = combScore(sm1, x0, c, bn, ref)
                if (s > bs) {
                    bs = s; fx = x0; fc = c
                }
            }
            df += 0.004f
        }

        // 4) уточнение методом наименьших квадратов по центрам линий
        val rx = refine(col1, fx, fc, bn) ?: Pair(fx, fc)
        val rowF = rowEdges(img, thr, rx.first.toInt(), min(w - 1, (rx.first + bn * rx.second).toInt()), ignore)
        val ry = refine(rowF, by, bcy, bn) ?: Pair(by, bcy)

        val side = bn * rx.second
        if (side < 0.40f * w || side > w * 1.02f) return null
        if (ry.first < 0f || ry.first + bn * ry.second > h) return null
        return GridFit(bn, rx.first, ry.first, rx.second, ry.second, min(bs, bestY), thr)
    }

    /** Число пикселей в каждом столбце, где есть резкий вертикальный переход цвета. */
    private fun colEdges(img: Img, thr: Int, y0: Int, y1: Int, ignore: Rect?): IntArray {
        val w = img.w
        val px = img.px
        val out = IntArray(w)
        var y = max(0, y0)
        val yEnd = min(img.h, y1)
        while (y < yEnd) {
            val base = y * w
            for (x in 1 until w - 1) {
                if (ignore != null && ignore.contains(x, y)) continue
                val a = px[base + x - 1]
                val b = px[base + x + 1]
                val d = abs(cr(a) - cr(b)) + abs(cg(a) - cg(b)) + abs(cb(a) - cb(b))
                if (d >= thr) out[x] += 2
            }
            y += 2
        }
        return out
    }

    /** То же для строк (переходы по вертикали) в полосе x0..x1. */
    private fun rowEdges(img: Img, thr: Int, x0: Int, x1: Int, ignore: Rect?): IntArray {
        val w = img.w
        val px = img.px
        val out = IntArray(img.h)
        val xs = max(0, x0)
        val xe = min(w - 1, x1)
        for (y in 1 until img.h - 1) {
            var cnt = 0
            var x = xs
            while (x <= xe) {
                if (ignore == null || !ignore.contains(x, y)) {
                    val a = px[(y - 1) * w + x]
                    val b = px[(y + 1) * w + x]
                    val d = abs(cr(a) - cr(b)) + abs(cg(a) - cg(b)) + abs(cb(a) - cb(b))
                    if (d >= thr) cnt += 2
                }
                x += 2
            }
            out[y] = cnt
        }
        return out
    }

    private fun smooth(a: IntArray, r: Int): IntArray = IntArray(a.size) { i ->
        var m = 0
        for (j in max(0, i - r)..min(a.size - 1, i + r)) if (a[j] > m) m = a[j]
        m
    }

    private fun sample(sm: IntArray, x: Float, ref: Float): Float {
        val i = x.roundToInt()
        if (i < 0 || i >= sm.size) return 0f
        return min(1f, sm[i] / ref)
    }

    /**
     * «Расчёска»: линии клеток на x0 + k·c (k = 0..n) должны быть сильными, середины клеток слабыми,
     * а следующая линия за границами поля — отсутствовать (чтобы не путать N и подрешётки).
     */
    private fun combScore(sm: IntArray, x0: Float, c: Float, n: Int, ref: Float): Float {
        var sum = 0f
        var minV = 1f
        for (k in 0..n) {
            val v = sample(sm, x0 + k * c, ref)
            sum += v
            if (v < minV) minV = v
        }
        var mid = 0f
        for (k in 0 until n) mid += sample(sm, x0 + (k + 0.5f) * c, ref)
        val outL = sample(sm, x0 - c, ref)
        val outR = sample(sm, x0 + (n + 1) * c, ref)
        return sum / (n + 1) - mid / n - 0.5f * (outL + outR) - 0.5f * (1f - minV)
    }

    /** Линейная регрессия положений линий: возвращает (начало, шаг). */
    private fun refine(p: IntArray, x0: Float, c: Float, n: Int): Pair<Float, Float>? {
        val win = max(4, (0.07f * c).toInt())
        var sk = 0.0
        var sx = 0.0
        var skk = 0.0
        var skx = 0.0
        var cnt = 0
        for (k in 0..n) {
            val pred = x0 + k * c
            val lo = max(0, (pred - win).roundToInt())
            val hi = min(p.size - 1, (pred + win).roundToInt())
            var sw = 0.0
            var swx = 0.0
            for (x in lo..hi) {
                sw += p[x]
                swx += p[x].toDouble() * x
            }
            if (sw < 1.0) continue
            val xk = swx / sw
            cnt++
            sk += k
            sx += xk
            skk += k.toDouble() * k
            skx += k * xk
        }
        if (cnt < n) return null
        val den = cnt * skk - sk * sk
        if (abs(den) < 1e-6) return null
        val b = (cnt * skx - sk * sx) / den
        val a = (sx - b * sk) / cnt
        if (abs(b - c) > 0.06 * c || abs(a - x0) > win) return null
        return Pair(a.toFloat(), b.toFloat())
    }

    // ───────────────────────── Цвета и поле ─────────────────────────

    fun avg(img: Img, x: Float, y: Float, half: Int = 2): Int {
        val cx = x.roundToInt()
        val cy = y.roundToInt()
        var r = 0
        var g = 0
        var b = 0
        var n = 0
        for (yy in cy - half..cy + half) {
            if (yy < 0 || yy >= img.h) continue
            for (xx in cx - half..cx + half) {
                if (xx < 0 || xx >= img.w) continue
                val p = img.px[yy * img.w + xx]
                r += cr(p); g += cg(p); b += cb(p); n++
            }
        }
        if (n == 0) return 0
        return rgb(r / n, g / n, b / n)
    }

    /** Определяет цвет пустой клетки (самый частый тёмный) и порог «занято» по расстоянию в RGB. */
    fun calibrateColors(img: Img, g: Geometry, ignore: Rect?, edgeThr: Int, strict: Boolean = false): Calibration? {
        val colors = ArrayList<Int>()
        for (r in 0 until g.n) for (c in 0 until g.n) {
            val x = g.cx(c)
            val y = g.cy(r)
            if (ignore != null && ignore.contains(x.toInt(), y.toInt())) continue
            colors.add(avg(img, x, y))
        }
        if (colors.isEmpty()) return null
        // «тёмная» = тёмные ВСЕ каналы: тёмно-красный блок (яркость ~93) раньше принимался за пустую клетку
        val dark = colors.filter { maxOf(cr(it), cg(it), cb(it)) < 110 }
        if (strict && dark.size < 3) return null
        val pool = if (dark.size >= 3) dark else colors
        val bins = HashMap<Int, Int>()
        fun key(c: Int) = ((cr(c) shr 4) shl 8) or ((cg(c) shr 4) shl 4) or (cb(c) shr 4)
        for (c in pool) bins[key(c)] = (bins[key(c)] ?: 0) + 1
        val modeKey = bins.maxByOrNull { it.value }?.key ?: return null
        var sr = 0L
        var sg = 0L
        var sb = 0L
        var cnt = 0
        for (c in pool) {
            if (key(c) == modeKey) {
                sr += cr(c); sg += cg(c); sb += cb(c); cnt++
            }
        }
        if (cnt == 0) return null
        if (strict && cnt < 3) return null
        var empty = rgb((sr / cnt).toInt(), (sg / cnt).toInt(), (sb / cnt).toInt())
        // уточнение: среднее по всем близким цветам
        sr = 0; sg = 0; sb = 0; cnt = 0
        for (c in pool) {
            if (dist(c, empty) < 30f) {
                sr += cr(c); sg += cg(c); sb += cb(c); cnt++
            }
        }
        if (cnt > 0) empty = rgb((sr / cnt).toInt(), (sg / cnt).toInt(), (sb / cnt).toInt())

        // порог: самый большой разрыв между «пустыми» и «занятыми» расстояниями
        val d = colors.map { dist(it, empty) }.sorted()
        var thr = 55f
        var bestGap = 0f
        for (i in 0 until d.size - 1) {
            if (d[i] > 60f) break
            val gap = d[i + 1] - d[i]
            if (gap >= 25f && gap > bestGap) {
                bestGap = gap
                thr = (d[i] + d[i + 1]) / 2f
            }
        }
        thr = thr.coerceIn(35f, 120f)
        return Calibration(g, empty, thr, edgeThr)
    }

    /** Насколько регулярна сетка на известном месте (0…1). Нужна для проверки «поле на месте». */
    fun gridScore(img: Img, g: Geometry, ignore: Rect?, edgeThr: Int): Float {
        val col = smooth(colEdges(img, edgeThr, g.y0.toInt(), g.bottom.toInt(), ignore), 3)
        val row = smooth(rowEdges(img, edgeThr, g.x0.toInt(), g.right.toInt(), ignore), 3)
        val sx = combScore(col, g.x0, g.cw, g.n, 0.5f * g.n * g.ch)
        val sy = combScore(row, g.y0, g.ch, g.n, 0.5f * g.n * g.cw)
        return min(sx, sy)
    }

    fun analyze(img: Img, cal: Calibration, ignore: Rect?, ratioHint: Float): Reading {
        val g = cal.geom
        val score = gridScore(img, g, ignore, cal.edgeThr)
        val field = Array(g.n) { IntArray(g.n) }
        var empties = 0
        for (r in 0 until g.n) {
            for (c in 0 until g.n) {
                val x = g.cx(c)
                val y = g.cy(r)
                if (ignore != null && ignore.contains(x.toInt(), y.toInt())) {
                    field[r][c] = -1
                    continue
                }
                val occ = if (dist(avg(img, x, y), cal.emptyColor) > cal.threshold) 1 else 0
                field[r][c] = occ
                if (occ == 0) empties++
            }
        }
        val valid = score >= 0.30f && empties >= 3
        val pieces = if (valid) readPieces(img, g, ratioHint, ignore) else emptyList()
        return Reading(field, pieces, score, empties)
    }

    /** Чёрный кадр (FLAG_SECURE или запрет записи): почти все точки чёрные. */
    fun isBlack(img: Img): Boolean {
        var dark = 0
        var total = 0
        val sx = max(1, img.w / 24)
        val sy = max(1, img.h / 40)
        var y = 0
        while (y < img.h) {
            var x = 0
            while (x < img.w) {
                total++
                if (lum(img.px[y * img.w + x]) < 6f) dark++
                x += sx
            }
            y += sy
        }
        return total > 0 && dark >= total * 0.985f
    }

    /** Два чтения совпадают по полю (кроме неизвестных клеток) и по фигурам. */
    fun same(a: Reading, b: Reading, cell: Float): Boolean {
        if (a.pieces.size != b.pieces.size) return false
        if (a.field.size != b.field.size) return false
        for (r in a.field.indices) for (c in a.field[r].indices) {
            val va = a.field[r][c]
            val vb = b.field[r][c]
            if (va != -1 && vb != -1 && va != vb) return false
        }
        for (i in a.pieces.indices) {
            val pa = a.pieces[i]
            val pb = b.pieces[i]
            if (pa.shape != pb.shape) return false
            if (abs(pa.left - pb.left) > 0.2f * cell || abs(pa.top - pb.top) > 0.2f * cell) return false
        }
        return true
    }

    // ───────────────────────── Фигуры ─────────────────────────

    private fun rowAvg(img: Img, y: Int, x0: Int, x1: Int): Int {
        var r = 0
        var g = 0
        var b = 0
        var n = 0
        for (x in max(0, x0)..min(img.w - 1, x1)) {
            val p = img.px[y * img.w + x]
            r += cr(p); g += cg(p); b += cb(p); n++
        }
        return if (n == 0) 0 else rgb(r / n, g / n, b / n)
    }

    /** «Цветной» пиксель: насыщенный и яркий, не похожий на фон слева/справа в этой же строке. */
    private fun colorful(p: Int, bg1: Int, bg2: Int): Boolean {
        val r = cr(p)
        val g = cg(p)
        val b = cb(p)
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        if (mx < 110 || mx - mn < 50) return false
        return dist(p, bg1) > 60f && dist(p, bg2) > 60f
    }

    /**
     * Находит фигуры под полем: цветные пиксели → полоса строк → колонки-кластеры → маски h×w.
     * ratioHint — известное отношение размера клетки фигуры к клетке поля (0 = неизвестно).
     */
    fun readPieces(img: Img, g: Geometry, ratioHint: Float, ignore: Rect?): List<PieceRead> {
        val w = img.w
        val h = img.h
        val c = g.cell
        val yA = g.bottom.toInt().plus((0.3f * c).toInt()).coerceIn(0, h - 1)
        val yB = (g.bottom + 5.0f * c).toInt().coerceIn(yA + 1, h)
        val bandH = yB - yA
        val mask = BooleanArray(w * bandH)
        val rowCnt = IntArray(bandH)
        for (yy in 0 until bandH) {
            val y = yA + yy
            val bgL = rowAvg(img, y, 2, 8)
            val bgR = rowAvg(img, y, w - 9, w - 3)
            var cnt = 0
            val base = y * w
            for (x in 0 until w) {
                if (ignore != null && ignore.contains(x, y)) continue
                if (colorful(img.px[base + x], bgL, bgR)) {
                    mask[yy * w + x] = true
                    cnt++
                }
            }
            rowCnt[yy] = cnt
        }

        // первая полоса строк с цветными пикселями (не берём рекламный баннер ниже)
        val gapRows = (0.4f * c).toInt()
        val minH = (0.15f * c).toInt()
        var ya = -1
        var yb = -1
        for (yy in 0 until bandH) {
            if (rowCnt[yy] < 3) continue
            if (ya < 0) {
                ya = yy; yb = yy
            } else if (yy - yb <= gapRows) {
                yb = yy
            } else if (yb - ya >= minH) {
                break
            } else {
                ya = yy; yb = yy
            }
        }
        if (ya < 0 || yb - ya < minH) return emptyList()

        val colCnt = IntArray(w)
        for (yy in ya..yb) for (x in 0 until w) if (mask[yy * w + x]) colCnt[x]++

        fun clusters(gap: Int): List<IntArray> {
            val res = ArrayList<IntArray>()
            var s = -1
            var e = -1
            for (x in 0 until w) {
                if (colCnt[x] < 2) continue
                if (s < 0) {
                    s = x; e = x
                } else if (x - e <= gap) {
                    e = x
                } else {
                    res.add(intArrayOf(s, e)); s = x; e = x
                }
            }
            if (s >= 0) res.add(intArrayOf(s, e))
            return res.filter { it[1] - it[0] + 1 >= 0.12f * c }
        }

        var chosen: List<IntArray>? = null
        for (gf in floatArrayOf(0.30f, 0.20f, 0.14f, 0.10f, 0.06f)) {
            val cl = clusters(max(2, (gf * c).toInt()))
            if (cl.size == 3) {
                chosen = cl
                break
            }
        }
        val cols = chosen ?: clusters(max(2, (0.14f * c).toInt()))
        if (cols.isEmpty()) return emptyList()

        // ограничивающие прямоугольники
        class Box(val xa: Int, val xb: Int, val top: Int, val bot: Int)
        val boxes = ArrayList<Box>()
        for (cl in cols) {
            var top = Int.MAX_VALUE
            var bot = -1
            for (yy in ya..yb) {
                var any = false
                for (x in cl[0]..cl[1]) {
                    if (mask[yy * w + x]) {
                        any = true; break
                    }
                }
                if (any) {
                    if (yy < top) top = yy
                    bot = yy
                }
            }
            if (bot >= 0) boxes.add(Box(cl[0], cl[1], top, bot))
        }
        if (boxes.isEmpty()) return emptyList()

        val dims = ArrayList<Float>()
        for (b in boxes) {
            dims.add((b.xb - b.xa + 1).toFloat())
            dims.add((b.bot - b.top + 1).toFloat())
        }
        val s = estimateCell(dims, c, ratioHint)

        val result = ArrayList<PieceRead>()
        for (b in boxes) {
            val pw = (b.xb - b.xa + 1).toFloat()
            val ph = (b.bot - b.top + 1).toFloat()
            val wc = (pw / s).roundToInt().coerceIn(1, 5)
            val hc = (ph / s).roundToInt().coerceIn(1, 5)
            val cwp = pw / wc
            val chp = ph / hc
            val half = max(1, (0.25f * min(cwp, chp)).toInt())
            val m = Array(hc) { BooleanArray(wc) }
            var any = false
            for (i in 0 until hc) {
                for (j in 0 until wc) {
                    val cx = (b.xa + (j + 0.5f) * cwp).roundToInt()
                    val cy = (b.top + (i + 0.5f) * chp).roundToInt()
                    var hit = 0
                    var tot = 0
                    for (yy in cy - half..cy + half) {
                        if (yy < 0 || yy >= bandH) continue
                        for (xx in cx - half..cx + half) {
                            if (xx < 0 || xx >= w) continue
                            tot++
                            if (mask[yy * w + xx]) hit++
                        }
                    }
                    if (tot > 0 && hit >= 0.4f * tot) {
                        m[i][j] = true
                        any = true
                    }
                }
            }
            if (!any) continue
            // старт: ближайшая к центру закрашенная клетка
            var sx = b.xa + pw / 2f
            var sy = yA + b.top + ph / 2f
            var bestD = Float.MAX_VALUE
            for (i in 0 until hc) for (j in 0 until wc) {
                if (!m[i][j]) continue
                val px = b.xa + (j + 0.5f) * cwp
                val py = yA + b.top + (i + 0.5f) * chp
                val dd = abs(px - (b.xa + pw / 2f)) + abs(py - (yA + b.top + ph / 2f))
                if (dd < bestD) {
                    bestD = dd; sx = px; sy = py
                }
            }
            result.add(PieceRead(Shape.fromMask(m), b.xa.toFloat(), (yA + b.top).toFloat(), pw, ph, (cwp + chp) / 2f, sx, sy))
        }
        return result
    }

    /** Размер клетки фигур: наибольший s, при котором все размеры почти целые (1…5 клеток). */
    private fun estimateCell(dims: List<Float>, c: Float, hint: Float): Float {
        fun err(s: Float): Float {
            var m = 0f
            for (d in dims) {
                val q = d / s
                val r = q.roundToInt()
                if (r < 1 || r > 5) return 9f
                m = max(m, abs(q - r))
            }
            return m
        }

        fun refined(s: Float): Float {
            var sd = 0f
            var sq = 0
            for (d in dims) {
                sd += d
                sq += max(1, (d / s).roundToInt())
            }
            return sd / sq
        }

        if (hint > 0f) {
            val s = hint * c
            if (err(s) <= 0.12f) return refined(s)
        }
        val sizes = ArrayList<Float>()
        val errs = ArrayList<Float>()
        var s = 0.95f * c
        while (s >= 0.28f * c) {
            sizes.add(s)
            errs.add(err(s))
            s -= 0.5f
        }
        var emin = 9f
        for (e in errs) if (e < emin) emin = e
        if (emin >= 9f) return refined(0.5f * c)
        // от крупных размеров к мелким: берём самый крупный из почти лучших по ошибке
        for (i in sizes.indices) {
            if (errs[i] <= emin + 0.05f) return refined(sizes[i])
        }
        return refined(0.5f * c)
    }
}
