package com.blockbot.auto

import android.content.Context
import android.content.Intent

object GameLauncher {
    const val DEFAULT_PKG = "com.block.juggle"

    data class AppInfo(val pkg: String, val label: String)

    /** Все приложения с иконкой запуска (кроме нашего). Нужен <queries> в манифесте. */
    fun launchableApps(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .distinctBy { it.pkg }
            .filter { it.pkg != ctx.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun installed(ctx: Context, pkg: String): Boolean =
        ctx.packageManager.getLaunchIntentForPackage(pkg) != null

    /** Сначала сохранённый выбор, затем com.block.juggle, затем поиск по названию «Block Blast». */
    fun find(ctx: Context, prefs: Prefs): String? {
        prefs.gamePkg?.let { if (installed(ctx, it)) return it }
        if (installed(ctx, DEFAULT_PKG)) return DEFAULT_PKG
        return launchableApps(ctx).firstOrNull { it.label.contains("block blast", ignoreCase = true) }?.pkg
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return true
    }
}
