package com.blockbot.auto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import androidx.annotation.RequiresApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executors
import kotlin.coroutines.resume

sealed class ShotResult {
    class Ok(val bitmap: Bitmap) : ShotResult()
    class Fail(val code: Int) : ShotResult()
}

/**
 * Служба специальных возможностей: выполняет жесты (dispatchGesture), делает снимки (Android 11+)
 * и следит за тем, какое приложение сейчас на переднем плане.
 */
class BotAccessibilityService : AccessibilityService() {

    private val shotExecutor = Executors.newSingleThreadExecutor()

    override fun onServiceConnected() {
        instance = this
        BotLog.add("Служба специальных возможностей подключена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        // события нашего плавающего меню и шторки уведомлений не считаются сменой приложения
        if (pkg == packageName && event.className?.toString()?.endsWith("Activity") != true) return
        if (pkg == "com.android.systemui") return
        foregroundPackage.value = pkg
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        shotExecutor.shutdown()
        super.onDestroy()
    }

    /** Перетаскивание пальцем по прямой с промежуточными точками. false — жест отменён или не отправлен. */
    suspend fun drag(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            val path = Path()
            path.moveTo(x1, y1)
            val steps = 8
            for (i in 1..steps) {
                val t = i / steps.toFloat()
                path.lineTo(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)
            }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(50L)))
                .build()
            val callback = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }
            val sent = try {
                dispatchGesture(gesture, callback, null)
            } catch (t: Throwable) {
                false
            }
            if (!sent && cont.isActive) cont.resume(false)
        }

    /** Снимок экрана средствами службы (Android 11+), без диалога. */
    @RequiresApi(Build.VERSION_CODES.R)
    suspend fun screenshot(): ShotResult = suspendCancellableCoroutine { cont ->
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, shotExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    val res: ShotResult = try {
                        val hb = result.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        val sw = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                        hb.close()
                        if (sw != null) ShotResult.Ok(sw) else ShotResult.Fail(-1)
                    } catch (t: Throwable) {
                        ShotResult.Fail(-2)
                    }
                    if (cont.isActive) cont.resume(res)
                }

                override fun onFailure(errorCode: Int) {
                    if (cont.isActive) cont.resume(ShotResult.Fail(errorCode))
                }
            })
        } catch (t: Throwable) {
            if (cont.isActive) cont.resume(ShotResult.Fail(-3))
        }
    }

    companion object {
        @Volatile
        var instance: BotAccessibilityService? = null

        /** Пакет окна, которое последним вышло на передний план. */
        val foregroundPackage = MutableStateFlow<String?>(null)
    }
}
