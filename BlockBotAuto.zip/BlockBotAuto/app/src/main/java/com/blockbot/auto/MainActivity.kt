package com.blockbot.auto

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.blockbot.auto.vision.Geometry
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class Screen { Main, Settings, Log, Picker, Manual }

enum class Guide { Accessibility, Overlay }

class MainActivity : ComponentActivity() {

    private lateinit var prefs: Prefs
    private var perms by mutableStateOf(PermState())
    private var screen by mutableStateOf(Screen.Main)
    private var guide by mutableStateOf<Guide?>(null)
    private var pendingStart = false
    private var pickerStartsBot = true

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == RESULT_OK && data != null) {
                ProjectionHolder.resultCode = res.resultCode
                ProjectionHolder.data = data
                refresh()
                if (pendingStart) {
                    pendingStart = false
                    onStartClicked()
                }
            } else {
                pendingStart = false
                Toast.makeText(this, getString(R.string.proj_denied), Toast.LENGTH_LONG).show()
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            refresh()
            if (granted && pendingStart) {
                pendingStart = false
                onStartClicked()
            } else {
                pendingStart = false
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContent { MaterialTheme { AppRoot() } }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        perms = Permissions.snapshot(this)
    }

    // ═════════════════════════ Логика «Старт» ═════════════════════════

    private fun onStartClicked() {
        refresh()
        val p = perms
        if (BotService.active) {
            Toast.makeText(this, "Бот уже работает. Остановите его кнопкой «Стоп» в плавающем меню.", Toast.LENGTH_LONG).show()
            return
        }
        if (!p.accessibility) { guide = Guide.Accessibility; return }
        if (!p.overlay) { guide = Guide.Overlay; return }
        if (!p.notifications) {
            pendingStart = true
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        if (BotAccessibilityService.instance == null) {
            Toast.makeText(this, getString(R.string.svc_not_running), Toast.LENGTH_LONG).show()
            guide = Guide.Accessibility
            return
        }
        if (Permissions.needsProjection() && !Permissions.projectionGranted()) {
            pendingStart = true
            requestProjection()
            return
        }
        val pkg = GameLauncher.find(this, prefs)
        if (pkg == null) {
            pickerStartsBot = true
            screen = Screen.Picker
            return
        }
        startBot(pkg)
    }

    private fun requestProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun startBot(pkg: String) {
        BotState.message.value = null
        ContextCompat.startForegroundService(
            this,
            Intent(this, BotService::class.java).setAction(BotService.ACTION_START).putExtra(BotService.EXTRA_PKG, pkg),
        )
        if (!GameLauncher.launch(this, pkg)) {
            Toast.makeText(this, "Не удалось запустить игру: $pkg", Toast.LENGTH_LONG).show()
        }
    }

    private suspend fun captureGame(): Bitmap? {
        val svc = BotAccessibilityService.instance
        if (Build.VERSION.SDK_INT < 30 || svc == null) {
            Toast.makeText(this, getString(R.string.manual_need_api), Toast.LENGTH_LONG).show()
            return null
        }
        GameLauncher.find(this, prefs)?.let { GameLauncher.launch(this, it) }
        delay(6000L)
        var result: Bitmap? = null
        repeat(5) {
            if (result == null) {
                when (val r = svc.screenshot()) {
                    is ShotResult.Ok -> result = r.bitmap
                    is ShotResult.Fail -> delay(400L)
                }
            }
        }
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
        )
        return result
    }

    // ═════════════════════════ Корневой экран ═════════════════════════

    @Composable
    private fun AppRoot() {
        Surface(Modifier.fillMaxSize().systemBarsPadding(), color = Color(0xFFF7F7FA)) {
            when (screen) {
                Screen.Main -> MainScreen()
                Screen.Settings -> SettingsScreen()
                Screen.Log -> LogScreen()
                Screen.Picker -> PickerScreen()
                Screen.Manual -> ManualCalibScreen()
            }
        }
        guide?.let { GuideDialog(it) }
        BackHandler(enabled = screen != Screen.Main) {
            screen = if (screen == Screen.Log || screen == Screen.Manual || screen == Screen.Picker && !pickerStartsBot) {
                Screen.Settings
            } else {
                Screen.Main
            }
        }
    }

    @Composable
    private fun GuideDialog(g: Guide) {
        val title = if (g == Guide.Accessibility) R.string.guide_acc_title else R.string.guide_overlay_title
        val text = if (g == Guide.Accessibility) R.string.guide_acc_text else R.string.guide_overlay_text
        AlertDialog(
            onDismissRequest = { guide = null },
            title = { Text(stringResource(title)) },
            text = { Text(stringResource(text), modifier = Modifier.verticalScroll(rememberScrollState())) },
            confirmButton = {
                TextButton(onClick = {
                    guide = null
                    if (g == Guide.Accessibility) Permissions.openAccessibilitySettings(this@MainActivity)
                    else Permissions.openOverlaySettings(this@MainActivity)
                }) { Text(stringResource(R.string.btn_open_settings)) }
            },
            dismissButton = {
                Column(horizontalAlignment = Alignment.End) {
                    if (g == Guide.Accessibility && Build.VERSION.SDK_INT >= 33) {
                        TextButton(onClick = {
                            guide = null
                            Permissions.openAppDetails(this@MainActivity)
                        }) { Text(stringResource(R.string.btn_restricted)) }
                    }
                    TextButton(onClick = { guide = null }) { Text(stringResource(R.string.btn_close)) }
                }
            },
        )
    }

    // ═════════════════════════ Главный экран ═════════════════════════

    @Composable
    private fun MainScreen() {
        val message by BotState.message.collectAsState()
        var expanded by remember { mutableStateOf(false) }
        val allOk = perms.required()
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { screen = Screen.Log }) { Text(stringResource(R.string.journal)) }
                TextButton(onClick = { screen = Screen.Settings }) { Text(stringResource(R.string.settings)) }
            }

            // чек-лист разрешений: сворачивается, когда всё ✅
            Surface(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                shadowElevation = 2.dp,
            ) {
                Column(Modifier.padding(14.dp)) {
                    if (allOk && !expanded) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(R.string.perm_all_ok), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            TextButton(onClick = { expanded = true }) { Text(stringResource(R.string.perm_show)) }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(R.string.perm_title), Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            if (allOk) TextButton(onClick = { expanded = false }) { Text(stringResource(R.string.perm_hide)) }
                        }
                        PermRow(
                            perms.accessibility, R.string.perm_acc_title, R.string.perm_acc_hint, R.string.btn_enable,
                        ) { guide = Guide.Accessibility }
                        PermRow(
                            perms.overlay, R.string.perm_overlay_title, R.string.perm_overlay_hint, R.string.btn_grant,
                        ) { guide = Guide.Overlay }
                        if (Permissions.needsProjection()) {
                            PermRow(
                                perms.projection, R.string.perm_proj_title, R.string.perm_proj_hint, R.string.btn_grant,
                            ) { requestProjection() }
                        }
                        if (Build.VERSION.SDK_INT >= 33) {
                            PermRow(
                                perms.notifications, R.string.perm_notif_title, R.string.perm_notif_hint, R.string.btn_grant,
                            ) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                        }
                        PermRow(
                            perms.battery, R.string.perm_batt_title, R.string.perm_batt_hint, R.string.btn_configure,
                        ) {
                            Toast.makeText(this@MainActivity, getString(R.string.batt_instruction), Toast.LENGTH_LONG).show()
                            Permissions.openBackgroundSettings(this@MainActivity)
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            StartButton { onStartClicked() }
            Spacer(Modifier.height(16.dp))

            message?.let {
                Surface(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFFE9ECFF),
                ) {
                    Text(it, Modifier.padding(14.dp), fontSize = 14.sp, textAlign = TextAlign.Center)
                }
            }
        }
    }

    @Composable
    private fun PermRow(ok: Boolean, title: Int, hint: Int, button: Int, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (ok) "✅" else "❌", fontSize = 20.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(stringResource(title), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                if (!ok) Text(stringResource(hint), fontSize = 12.sp, color = Color(0xFF666B80))
            }
            if (!ok) {
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = onClick) { Text(stringResource(button), fontSize = 12.sp) }
            }
        }
    }

    /** Большая круглая кнопка: синий вертикальный градиент, два сиреневых полупрозрачных кольца с «пульсом». */
    @Composable
    private fun StartButton(onClick: () -> Unit) {
        val t = rememberInfiniteTransition(label = "pulse")
        val s1 by t.animateFloat(
            initialValue = 1f,
            targetValue = 1.06f,
            animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "ring1",
        )
        val s2 by t.animateFloat(
            initialValue = 1.02f,
            targetValue = 1.10f,
            animationSpec = infiniteRepeatable(tween(1500, delayMillis = 250, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "ring2",
        )
        Box(Modifier.size(320.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(290.dp).scale(s2).clip(CircleShape).background(Color(0x22B7BAF5)))
            Box(
                Modifier.size(248.dp).scale(s1).clip(CircleShape)
                    .background(Color(0x40B7BAF5))
                    .border(1.dp, Color(0x55B7BAF5), CircleShape),
            )
            Box(
                Modifier.size(200.dp).clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(Color(0xFF4A90FF), Color(0xFF2A2EE0))))
                    .clickable(onClick = onClick),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    stringResource(R.string.start),
                    color = Color.White,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                )
            }
        }
    }

    // ═════════════════════════ Настройки ═════════════════════════

    @Composable
    private fun SliderRow(
        label: String,
        value: Float,
        range: ClosedFloatingPointRange<Float>,
        steps: Int,
        fmt: (Float) -> String,
        onChange: (Float) -> Unit,
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row {
                Text(label, Modifier.weight(1f), fontSize = 14.sp)
                Text(fmt(value), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
            Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
        }
    }

    @Composable
    private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), fontSize = 14.sp)
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }

    @Composable
    private fun SettingsScreen() {
        var speed by remember { mutableStateOf(prefs.speed) }
        var dragMs by remember { mutableStateOf(prefs.dragMs.toFloat()) }
        var delayMs by remember { mutableStateOf(prefs.moveDelayMs.toFloat()) }
        var limit by remember { mutableStateOf(prefs.moveLimit.toFloat()) }
        var debug by remember { mutableStateOf(prefs.debugFrames) }
        var manual by remember { mutableStateOf(prefs.useManualOffset) }
        var mx by remember { mutableStateOf(prefs.manualOffX) }
        var my by remember { mutableStateOf(prefs.manualOffY) }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { screen = Screen.Main }) { Text(stringResource(R.string.back)) }
                Text(stringResource(R.string.settings), fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
            SliderRow(stringResource(R.string.set_speed), speed, 0.5f..2f, 14, { "%.1f×".format(it) }) {
                speed = it; prefs.speed = it
            }
            SliderRow(stringResource(R.string.set_drag), dragMs, 150f..800f, 64, { "${it.toInt()}" }) {
                dragMs = it; prefs.dragMs = it.toInt()
            }
            SliderRow(stringResource(R.string.set_delay), delayMs, 100f..1500f, 27, { "${it.toInt()}" }) {
                delayMs = it; prefs.moveDelayMs = it.toInt()
            }
            SliderRow(stringResource(R.string.set_limit), limit, 0f..500f, 49, { if (it < 1f) "∞" else "${it.toInt()}" }) {
                limit = it; prefs.moveLimit = it.toInt()
            }
            SwitchRow(stringResource(R.string.set_debug), debug) { debug = it; prefs.debugFrames = it }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            SwitchRow(stringResource(R.string.set_manual_offset), manual) {
                manual = it; prefs.useManualOffset = it
            }
            if (manual) {
                SliderRow(stringResource(R.string.set_offset_x), mx, -3f..4f, 69, { "%.1f".format(it) }) {
                    mx = it; prefs.manualOffX = it
                }
                SliderRow(stringResource(R.string.set_offset_y), my, -3f..6f, 89, { "%.1f".format(it) }) {
                    my = it; prefs.manualOffY = it
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            OutlinedButton(
                onClick = {
                    prefs.resetCalibration()
                    Toast.makeText(this@MainActivity, getString(R.string.set_cal_reset_done), Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.set_reset_cal)) }
            OutlinedButton(onClick = { screen = Screen.Manual }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.set_manual_geom))
            }
            OutlinedButton(
                onClick = { pickerStartsBot = false; screen = Screen.Picker },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.set_change_game)) }
            OutlinedButton(
                onClick = {
                    Toast.makeText(this@MainActivity, getString(R.string.set_disable_hint), Toast.LENGTH_LONG).show()
                    Permissions.openAccessibilitySettings(this@MainActivity)
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.set_disable_service)) }
            OutlinedButton(onClick = { screen = Screen.Log }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.journal))
            }
        }
    }

    // ═════════════════════════ Журнал ═════════════════════════

    @Composable
    private fun LogScreen() {
        val lines by BotLog.lines.collectAsState()
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { screen = Screen.Main }) { Text(stringResource(R.string.back)) }
                Text(stringResource(R.string.journal), Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TextButton(onClick = {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("journal", lines.joinToString("\n")))
                    Toast.makeText(this@MainActivity, "Скопировано", Toast.LENGTH_SHORT).show()
                }) { Text("Копировать") }
                TextButton(onClick = { BotLog.clear() }) { Text("Очистить") }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(lines.asReversed()) { line ->
                    Text(line, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 2.dp))
                }
            }
        }
    }

    // ═════════════════════════ Выбор игры ═════════════════════════

    @Composable
    private fun PickerScreen() {
        val apps = remember { GameLauncher.launchableApps(this@MainActivity) }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text(stringResource(R.string.picker_title), fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(stringResource(R.string.picker_help), fontSize = 13.sp, color = Color(0xFF666B80))
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(apps) { app ->
                    Column(
                        Modifier.fillMaxWidth()
                            .clickable {
                                prefs.gamePkg = app.pkg
                                val start = pickerStartsBot
                                screen = if (start) Screen.Main else Screen.Settings
                                if (start) startBot(app.pkg)
                            }
                            .padding(vertical = 10.dp),
                    ) {
                        Text(app.label, fontWeight = FontWeight.SemiBold)
                        Text(app.pkg, fontSize = 11.sp, color = Color.Gray)
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    // ═════════════════════════ Ручная калибровка (запасной вариант) ═════════════════════════

    @Composable
    private fun ManualCalibScreen() {
        var bmp by remember { mutableStateOf<Bitmap?>(null) }
        var taps by remember { mutableStateOf(listOf<Offset>()) }
        var n by remember { mutableStateOf(8) }
        var busy by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { screen = Screen.Settings }) { Text(stringResource(R.string.back)) }
                Text(stringResource(R.string.manual_title), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Text(stringResource(R.string.manual_help), fontSize = 12.sp, color = Color(0xFF666B80))
            Spacer(Modifier.height(8.dp))
            Row {
                Button(enabled = !busy, onClick = {
                    scope.launch {
                        busy = true
                        bmp = captureGame()
                        taps = emptyList()
                        busy = false
                    }
                }) { Text(stringResource(R.string.manual_shot)) }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = {
                    prefs.useManualGeom = false
                    Toast.makeText(this@MainActivity, "Автоопределение включено", Toast.LENGTH_SHORT).show()
                }) { Text(stringResource(R.string.manual_disable), fontSize = 12.sp) }
            }
            val b = bmp
            if (b != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Размер: ", fontSize = 13.sp)
                    (6..10).forEach { v ->
                        TextButton(onClick = { n = v }) {
                            Text(if (n == v) "[$v]" else "$v", fontWeight = if (n == v) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
                Image(
                    bitmap = b.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier.fillMaxWidth()
                        .pointerInput(b) {
                            detectTapGestures { pos ->
                                val k = b.width / size.width.toFloat()
                                taps = (taps + Offset(pos.x * k, pos.y * k)).takeLast(2)
                            }
                        }
                        .drawWithContent {
                            drawContent()
                            val k = size.width / b.width
                            taps.forEach { drawCircle(Color.Red, 12f, Offset(it.x * k, it.y * k)) }
                        },
                )
                Text(
                    "Точки (px): " + taps.joinToString("  ") { "(${it.x.toInt()}, ${it.y.toInt()})" },
                    fontSize = 12.sp,
                )
                Row {
                    Button(enabled = taps.size == 2, onClick = {
                        val x0 = minOf(taps[0].x, taps[1].x)
                        val y0 = minOf(taps[0].y, taps[1].y)
                        val x1 = maxOf(taps[0].x, taps[1].x)
                        val y1 = maxOf(taps[0].y, taps[1].y)
                        prefs.saveManualGeom(Geometry(n, x0, y0, (x1 - x0) / n, (y1 - y0) / n))
                        prefs.useManualGeom = true
                        Toast.makeText(this@MainActivity, getString(R.string.manual_saved), Toast.LENGTH_LONG).show()
                    }) { Text(stringResource(R.string.manual_save)) }
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { taps = emptyList() }) { Text(stringResource(R.string.manual_clear)) }
                }
            }
        }
    }
}
