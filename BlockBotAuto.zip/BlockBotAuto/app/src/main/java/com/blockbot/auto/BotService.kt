package com.blockbot.auto

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Foreground-сервис: держит процесс живым, показывает плавающее меню и запускает BotRunner.
 * Тип сервиса: specialUse (Android 14+); mediaProjection только на Android 10, где нужна запись экрана.
 */
class BotService : Service() {

    private var scope: CoroutineScope? = null
    private var job: Job? = null
    private var overlay: Overlay? = null
    private var capturer: Capturer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> shutdown(returnToApp = true, message = null)
            ACTION_START -> {
                if (!active) startBot(intent?.getStringExtra(EXTRA_PKG) ?: GameLauncher.DEFAULT_PKG)
            }
            else -> if (!active) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startBot(pkg: String) {
        active = true
        createChannel()
        val usesProjection = Build.VERSION.SDK_INT < 30
        val type = when {
            Build.VERSION.SDK_INT >= 34 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            Build.VERSION.SDK_INT == 29 && usesProjection -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            else -> 0
        }
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)

        BotState.resetForStart()
        val svc = BotAccessibilityService.instance
        if (svc == null) {
            shutdown(true, "Служба специальных возможностей не запущена. Включите её в настройках и нажмите «Старт».")
            return
        }

        val ov = Overlay(
            this,
            onPauseToggle = { BotState.togglePause() },
            onStop = { shutdown(returnToApp = true, message = "Остановлено кнопкой «Стоп».") },
        )
        overlay = ov
        ov.show()

        val cap: Capturer = if (!usesProjection) {
            AccessibilityCapturer(svc)
        } else {
            val data = ProjectionHolder.data
            if (data == null) {
                shutdown(true, "Нет разрешения на запись экрана. Нажмите «Старт» и разрешите запись.")
                return
            }
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection: MediaProjection = try {
                mpm.getMediaProjection(ProjectionHolder.resultCode, data)
            } catch (t: Throwable) {
                ProjectionHolder.clear()
                shutdown(true, "Разрешение на запись экрана устарело. Нажмите «Старт» и выдайте его снова.")
                return
            }
            ProjectionCapturer(this, projection)
        }
        capturer = cap

        val sc = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope = sc
        // меню и уведомление следят за общим состоянием
        sc.launch(Dispatchers.Main) { BotState.paused.collect { ov.setPaused(it) } }
        sc.launch(Dispatchers.Main) { BotState.status.collect { ov.setStatus(it) } }
        job = sc.launch {
            val runner = BotRunner(applicationContext, svc, cap, ov, pkg)
            val message = runner.run()
            withContext(Dispatchers.Main) { shutdown(returnToApp = true, message = message) }
        }
    }

    /** Мгновенно отменяет корутины, убирает меню, останавливает сервис. Службу доступности не отключаем. */
    private fun shutdown(returnToApp: Boolean, message: String?) {
        val wasActive = active
        active = false
        job?.cancel()
        scope?.cancel()
        job = null
        scope = null
        overlay?.remove()
        overlay = null
        capturer?.release()
        capturer = null
        if (Build.VERSION.SDK_INT < 30) ProjectionHolder.clear()
        if (message != null) {
            BotState.message.value = message
            BotLog.add(message)
        }
        BotState.running.value = false
        BotState.paused.value = false
        BotState.status.value = ""
        if (wasActive) {
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (t: Throwable) { }
        }
        stopSelf()
        if (returnToApp) {
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                )
            } catch (t: Throwable) {
                BotLog.add("Не удалось вернуться на главный экран: ${t.message}")
            }
        }
    }

    override fun onDestroy() {
        if (active) shutdown(returnToApp = false, message = null)
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW),
            )
        }
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BotService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, getString(R.string.notif_stop), stop)
            .build()
    }

    companion object {
        const val ACTION_START = "com.blockbot.auto.START"
        const val ACTION_STOP = "com.blockbot.auto.STOP"
        const val EXTRA_PKG = "pkg"
        private const val CHANNEL = "bot"
        private const val NOTIF_ID = 17

        @Volatile
        var active = false
    }
}
