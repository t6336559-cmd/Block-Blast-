package com.blockbot.auto

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Плавающее полупрозрачное меню: статус, ⏸ Пауза/Продолжить, ⏹ Стоп. Перетаскивается и прилипает к краю.
 * На время снимка скрывается (INVISIBLE), а область под ним игнорируется при распознавании.
 */
class Overlay(
    private val ctx: Context,
    private val onPauseToggle: () -> Unit,
    private val onStop: () -> Unit,
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val dm = ctx.resources.displayMetrics
    private var root: LinearLayout? = null
    private var statusView: TextView? = null
    private var pauseBtn: TextView? = null
    private var params: WindowManager.LayoutParams? = null

    /** Прямоугольник меню на экране (обновляется после каждой раскладки). */
    @Volatile
    var rect: Rect? = null
        private set

    private fun dp(v: Int): Int = (v * dm.density).toInt()

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    fun show() = onMain {
        if (root != null) return@onMain
        val bg = GradientDrawable().apply {
            setColor(0xDD10131F.toInt())
            cornerRadius = dp(14).toFloat()
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            alpha = 0.6f
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val status = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            maxLines = 4
            maxWidth = dp(190)
            ellipsize = android.text.TextUtils.TruncateAt.END
            text = "Запуск…"
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun button(label: String, action: () -> Unit): TextView = TextView(ctx).apply {
            text = label
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(40))
            setOnClickListener { action() }
        }
        val pause = button("⏸") { onPauseToggle() }
        val stop = button("⏹") { onStop() }
        row.addView(pause)
        row.addView(stop)
        box.addView(status)
        box.addView(row)

        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dm.widthPixels - dp(150)
        p.y = (dm.heightPixels * 0.12f).toInt()

        // перетаскивание за строку статуса
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        status.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (e.rawX - downX).toInt()
                    p.y = startY + (e.rawY - downY).toInt()
                    try { wm.updateViewLayout(box, p) } catch (t: Throwable) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val w = box.width
                    val h = box.height
                    p.x = if (p.x + w / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - w
                    p.y = p.y.coerceIn(0, (dm.heightPixels - h).coerceAtLeast(0))
                    try { wm.updateViewLayout(box, p) } catch (t: Throwable) { }
                    true
                }
                else -> false
            }
        }
        box.viewTreeObserver.addOnGlobalLayoutListener {
            val loc = IntArray(2)
            box.getLocationOnScreen(loc)
            rect = Rect(loc[0], loc[1], loc[0] + box.width, loc[1] + box.height)
        }
        try {
            wm.addView(box, p)
            root = box
            statusView = status
            pauseBtn = pause
            params = p
        } catch (t: Throwable) {
            BotLog.add("Не удалось показать плавающее меню: ${t.message}")
        }
    }

    fun setStatus(text: String) = onMain { statusView?.text = text }

    fun setPaused(paused: Boolean) = onMain { pauseBtn?.text = if (paused) "▶️" else "⏸" }

    fun remove() = onMain {
        root?.let {
            try { wm.removeView(it) } catch (t: Throwable) { }
        }
        root = null
        rect = null
    }

    /** Скрывает меню на время block (снимок экрана) и сразу показывает обратно. */
    suspend fun <T> hidden(block: suspend () -> T): T {
        val r = root ?: return block()
        withContext(Dispatchers.Main) { r.visibility = View.INVISIBLE }
        delay(90)
        try {
            return block()
        } finally {
            withContext(NonCancellable + Dispatchers.Main) { r.visibility = View.VISIBLE }
        }
    }
}
